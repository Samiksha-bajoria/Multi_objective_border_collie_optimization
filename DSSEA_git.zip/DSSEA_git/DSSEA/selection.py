"""
selection.py — Stage 2 of DSSEA: selective mating-pool construction.

Stage 1 (archive.py) already built an elitist, exploration-oriented
archive. Stage 2 turns that archive into a mating pool through a
SECOND, distinct selection operator: every archive member is given a
"selective score"

    score = selective_pressure * rank_score
            + (1 - selective_pressure) * crowding_score

where `rank_score` rewards a low (good) Pareto rank inside the archive
and `crowding_score` rewards sitting in a sparse region of the
(min-max normalised) objective space; `selective_pressure` therefore
tunes how much this stage favours pure convergence (-> 1) versus pure
diversity (-> 0). Binary tournament mating selection is then run on
this score (higher is better) exactly the way SPEA2-style optimisers
run it on a scalar fitness, giving DSSEA a second, independently
tunable selection pressure layered on top of Stage 1's elitism.
"""

import numpy as np


def selective_score(F, rank, crowd, objective_types):
    """Blend Pareto rank and crowding distance into one Stage-2 score
    (higher is better). Purely a re-weighting of quantities already
    computed by diversity.rank_and_crowding -- no direction handling is
    needed here because both rank and crowd are already direction-aware
    / direction-agnostic respectively."""
    max_rank = rank.max() if rank.size else 0
    rank_score = 1.0 - rank / max(max_rank, 1)

    finite = np.isfinite(crowd)
    fallback = crowd[finite].max() if np.any(finite) else 1.0
    crowd_clean = np.where(finite, crowd, fallback)
    crowd_max = crowd_clean.max() if crowd_clean.size and crowd_clean.max() > 0 else 1.0
    crowd_score = crowd_clean / crowd_max
    return rank_score, crowd_score


def blended_score(rank_score, crowd_score, selective_pressure):
    return selective_pressure * rank_score + (1.0 - selective_pressure) * crowd_score


def binary_tournament(score, n_select, rng):
    """Indices of the winners of `n_select` binary tournaments; HIGHER
    score wins (score is a Stage-2 selective score, not a raw-fitness
    minimisation target)."""
    n = len(score)
    if n == 0:
        raise ValueError("empty archive: cannot run mating selection")
    if n == 1:
        return np.zeros(n_select, dtype=int)
    a = rng.integers(0, n, size=n_select)
    b = rng.integers(0, n, size=n_select)
    same = a == b
    if np.any(same):
        b[same] = (b[same] + 1 + rng.integers(0, n - 1, size=same.sum())) % n
    winners = np.where(score[a] >= score[b], a, b)
    return winners


def mating_pool(X_archive, score, pool_size, rng):
    """Decision vectors of the selected parents."""
    idx = binary_tournament(np.asarray(score, dtype=float), pool_size, rng)
    return X_archive[idx].copy()
