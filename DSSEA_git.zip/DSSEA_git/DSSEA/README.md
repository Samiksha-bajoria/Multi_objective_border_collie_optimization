# DSSEA — Dual-Stage Selective Evolutionary Algorithm

A from-scratch, modular Python implementation of DSSEA for multi-objective
optimisation with **native support for mixed minimise/maximise objectives** —
no objective is ever converted to minimisation via `-f`, reciprocals, or any
other sign trick. Every dominance test, ranking, environmental-selection step
and performance metric consults each objective's own direction
(`'min'` / `'max'`) and applies the matching comparison.

Run this first:

```bash
python check.py
```

It verifies the installation and — more importantly — that the mixed
minimise/maximise machinery actually behaves the way it claims (dominance
respects `'max'` columns, no objective was silently sign-flipped, the
analytic reference fronts are internally non-dominated, and a short DSSEA
run improves hypervolume from the first to the last iteration).

---

## 1. Installation

```bash
cd DSSEA
python3 -m venv .venv && source .venv/bin/activate   # optional but recommended
pip install -r requirements.txt
python check.py
```

Requires Python 3.11+. Dependencies: `numpy`, `pandas`, `openpyxl`, `matplotlib`.

---

## 2. Project structure

```
DSSEA/
├── main.py                      # entry point (CLI)
├── check.py                     # self-check: run this first
├── config.py                    # every tunable parameter, single source of truth
├── optimizer.py                 # the DSSEA loop (Stage 1 + Stage 2)
├── archive.py                   # Stage 1 — exploration / elitist archive
├── selection.py                 # Stage 2 — selective mating-pool construction
├── diversity.py                 # crowding distance + adaptive niche radius
├── dominance.py                 # direction-aware Pareto dominance (core primitive)
├── nondominated_sort.py         # direction-aware fast non-dominated sorting
├── crossover.py                 # SBX crossover
├── mutation.py                  # polynomial mutation
├── dataset.py                   # the problem registry (27 problems)
├── standard_test_functions.py   # ZDT1,2,3,4,6 and DTLZ1-7 (pure minimisation)
├── mixed_test_functions.py      # Mixed_ZDT1, Mixed_DTLZ1, Mixed_DTLZ2 (mixed min/max)
├── evopinn_problem.py           # supplied verbatim — the 12 EvoPINN problems
├── generate.py                  # analytic / approximated reference (expected) fronts
├── metrics.py                   # Hypervolume, GD, IGD, Spacing, Spread, Epsilon
├── run_experiment.py            # everything that happens for ONE problem
├── excel_writer.py              # per-problem workbook + cross-problem master summary
├── visualization.py             # expected-vs-reality, HV, objective/decision space, convergence
├── requirements.txt
├── README.md
├── results/                     # DSSEA_<Problem>.xlsx + DSSEA_Master_Summary.xlsx
└── figures/                     # <Problem>_*.png
```

---

## 3. The 27 problems (exactly these, nothing else)

| Family | Names | Objectives |
|---|---|---|
| EvoPINN | `EvoPINN1_Poisson1D` … `EvoPINN12_Schrodinger1D` | 4, all minimised |
| ZDT | `ZDT1, ZDT2, ZDT3, ZDT4, ZDT6` | 2, all minimised |
| DTLZ | `DTLZ1 … DTLZ7` | 3, all minimised |
| Mixed | `Mixed_ZDT1, Mixed_DTLZ1, Mixed_DTLZ2` | mixed `'min'`/`'max'` |

`dataset.PROBLEM_NAMES` is exactly these 27 names — `config.py`'s
`problems: []` default means "run all of them"; pass `--problems ...` to run a
subset instead.

### The three Mixed problems

Each maximised component is a *genuinely different, conflicting* quantity —
never a sign-flipped copy of a minimised one — so the trade-off is real and
each problem still has a closed-form reference front (see
`mixed_test_functions.py` / `generate.py` for the derivations):

- **Mixed_ZDT1**: `f1 = x1` (minimise, "cost"), `f2 = sqrt(x1) / g` (maximise, "yield").
- **Mixed_DTLZ1**: two minimised "cost" terms, `f3 = 0.5·x1/(1+g)` (maximise, "throughput").
- **Mixed_DTLZ2**: two minimised "interference" terms, `f3 = cos(x1·π/2)/(1+g)` (maximise, "signal strength").

---

## 4. DSSEA algorithm — Stage 1 + Stage 2

```
P_0 <- random population,  A_0 <- empty
repeat
    Stage 1 (archive.py)   : A_{t+1} <- exploration selection of P_t U A_t
                              (non-dominated sorting + crowding distance;
                               adaptive hypergrid truncation on overflow)
    Stage 2 (selection.py) : score every member of A_{t+1} with the
                              adaptively-weighted rank/crowding selective
                              score, then binary-tournament mating
                              selection on that score
    P_{t+1} <- SBX crossover + polynomial mutation of the mating pool
until t = max_iterations
```

**Honesty note on algorithm fidelity.** DSSEA is implemented here as a fully
documented, from-scratch two-stage selection scheme built to this project's
own specification (Stage 1: exploration / elitist archive via non-dominated
sorting + crowding; Stage 2: exploitation / selective mating-pool
construction via an adaptively-weighted rank-vs-diversity score,
`config.selective_pressure`). It reuses Pareto ranking and crowding distance
as generic building blocks — as most elitist MOEAs do — but Stage 2's
blended, independently-tunable selective score is this project's own
operator, not a re-skin of NSGA-II, MOEA/D or SPEA2. See the module
docstrings in `optimizer.py`, `archive.py` and `selection.py` for the exact
mechanics.

Mixed minimise/maximise objective sets are supported natively throughout:
every dominance test consults `problem['objective_types']`, and objective
values are stored and reported exactly as the test function produced them.

---

## 5. Configuration (`config.py`)

Defaults match the brief:

```python
n_population   = 100
archive_size   = 100
max_iterations = 100
n_runs         = 40
```

Other knobs: `crossover_prob`, `eta_c`, `mutation_prob` (`None` → `1/dim`),
`eta_m`, `grid_divisions` (Stage-1 adaptive hypergrid), `selective_pressure` /
`selective_pressure_end` / `adaptive_pressure` (Stage-2 blend), `hv_mc_samples_final`,
`hv_mc_samples_history`, `ref_front_size`, `hv_margin`, `history_every`,
`history_metric_runs`, `base_seed`, and `problems` (the benchmark subset).

---

## 6. Running experiments

```bash
# Full campaign: all 27 problems, 40 runs x 100 iterations, population 100
python main.py

# Smoke test (3 runs x 10 iterations)
python main.py --quick

# A subset of problems
python main.py --problems ZDT1 Mixed_DTLZ2 EvoPINN1_Poisson1D

# Override any core knob from the CLI
python main.py --runs 40 --iterations 100 --population 100 --archive 100

# Skip figure generation (faster, Excel only)
python main.py --no-figures
```

Every step prints to the terminal as it happens: which problem is running,
each run's front/archive size and wall-clock time, the reference-front kind,
the aggregated HV/IGD/GD, the workbook path, and every figure path — so you
can follow the whole campaign live without opening a single file until it's
done.

Seeds are deterministic (`seed = base_seed + run_index`), so every run is
independently reproducible; the seed used is not itself stored per row (per
the required `Run_Summary` layout) but `base_seed` is recorded once in the
`Parameters` sheet of every workbook.

**Runtime note:** the EvoPINN problems evaluate a small hand-coded MLP with
forward-mode derivatives per individual per generation, so they are
noticeably slower per evaluation than ZDT/DTLZ. Use `--quick` first to sanity
check the pipeline.

---

## 7. Outputs

### `results/DSSEA_<Problem>.xlsx` — one workbook per problem, sheet order:

1. **Run_Summary** — *required layout*, one row per run:

   | Run | Hypervolume | IGD | GD | Spacing | Spread | Epsilon | Runtime |
   |---|---|---|---|---|---|---|---|

2. **Statistics** — mean / std / median / best / worst per indicator across all runs.
3. **Parameters** — the exact DSSEA configuration used for that problem.
4. **Objective_Info** — index, name, direction (Minimize/Maximize), best/worst observed.
5. **Iteration_History** — convergence trace (HV/IGD/GD/archive/front size), averaged
   across the traced runs.
6. **Pareto_Solutions** — decision variables + objectives of the best run's final front.
7. **Archive** — the best run's full external Stage-1 archive.
8. **Reference_Front** — the "expected" front (analytic, or approximated for EvoPINN).
9. **Expected_vs_Reality** — per-objective best/worst, expected vs. obtained, with the gap.

### `results/DSSEA_Master_Summary.xlsx`

One row per problem (`Master_Summary`), the full per-run metric dump across
every problem (`All_Runs`), and the exact configuration used (`Configuration`).

### `figures/<Problem>_*.png`

| File | What it shows |
|---|---|
| `..._front.png` | **Expected vs. obtained** Pareto front (2-D scatter, 3-D scatter + projection, or parallel-coordinates + log-log scatter for the 4-objective EvoPINN problems). |
| `..._hypervolume.png` | **Hypervolume vs. generation** — mean curve ± 1 std band across the traced runs. |
| `..._objective_space.png` | **Objective space** — every run's final front overlaid, colour-coded by run index, against the reference front. |
| `..._decision_space.png` | **Decision space** — every run's final Pareto-optimal decisions (x1 vs x2), colour-coded by run index. |
| `..._convergence.png` | **Convergence graph** — mean HV / IGD / GD and archive/front size per iteration. |
| `..._distribution.png` | Boxplots of all six indicators over every independent run. |
| `00_overview_hypervolume.png` | Cross-problem mean hypervolume comparison. |

---

## 8. Performance metrics (`metrics.py`)

All six indicators share one fixed `MetricContext` per problem (built once
from the reference front, so every run's numbers are directly comparable):

- **Hypervolume (HV)** — normalised to `[0, 1]`; exact for 2 objectives, Monte-Carlo
  for 3+. Direction-aware reference point placed on the *worse* side of each
  objective's own direction.
- **GD / IGD** — mean nearest-neighbour distance, obtained→reference and
  reference→obtained.
- **Spacing** — std. dev. of nearest-neighbour distances inside the obtained front.
- **Spread (Δ)** — generalised diversity metric using the reference front's extremes.
- **Epsilon (additive, I_eps+)** — smallest ε such that every reference point is
  ε-dominated by some obtained point; direction-aware.
- **Runtime**, **Pareto Set Size** — bookkeeping metrics logged every run.

---

## 9. Adding a new benchmark problem

1. Write an `evaluate(x) -> np.ndarray(n_obj)` function.
2. Build the uniform problem dictionary (see `standard_test_functions._problem`
   or `mixed_test_functions.py` for worked examples):
   `name, description, dim, n_obj, bounds, objective_types, evaluate, true_front`.
   `objective_types` is a plain list of `'min'`/`'max'` strings — mix them freely.
   **Never negate a maximisation objective inside `evaluate`** — return its true
   value; the direction tag alone tells DSSEA to maximise it.
3. Register the builder in `STANDARD_BUILDERS` or `MIXED_BUILDERS` and add the
   name to `dataset.PROBLEM_NAMES`.
4. If a closed-form Pareto front exists, add a `true_front_*` generator in
   `generate.py` and wire it into `TRIE_FRONTS`/the builder's `true_front` arg;
   otherwise leave `true_front=None` and the approximated (non-dominated union
   of all runs) reference front is used automatically.

## 10. Changing objective directions

Directions live entirely in `problem['objective_types']` (a list of
`'min'`/`'max'` strings) — see `mixed_test_functions.py` for worked examples of
flipping one component of an otherwise-minimised problem to maximisation. No
other file needs to change: `dominance.py`, `nondominated_sort.py`,
`archive.py`, `selection.py`, and `metrics.py` all read `objective_types` at
call time.

---

## 11. Troubleshooting

| Symptom | Likely cause / fix |
|---|---|
| `ModuleNotFoundError: openpyxl` | `pip install -r requirements.txt` |
| `python check.py` reports a FAIL | Read the specific check line — it names exactly which problem/behaviour failed (e.g. a maximised objective going negative would mean a sign-flip bug). |
| EvoPINN runs are slow | Expected — MLP forward+derivative evaluation per individual is more expensive than ZDT/DTLZ. Use `--quick` first, then the full 40×100 run. |
| Figures look empty/flat | With `--quick` settings the population may not have converged yet; use the full `n_population=100, max_iterations=100` configuration for publication-quality fronts. |
| `Summary.xlsx` only has some problems | `write_master_summary` is called once at the end of `main.py` with every problem processed in that invocation — run the full campaign (or a superset of `--problems`) to regenerate everything at once. |
