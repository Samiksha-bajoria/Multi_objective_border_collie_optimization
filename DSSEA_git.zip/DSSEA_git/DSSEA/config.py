"""
config.py — every tunable knob of the DSSEA experiment lives here.

Nothing in this project hard-codes a parameter: optimizer.py, archive.py,
selection.py, run_experiment.py, excel_writer.py and visualization.py all
read from a single DSSEAConfig object.
"""

from dataclasses import dataclass, field, asdict
from pathlib import Path


@dataclass
class DSSEAConfig:
    # ---- DSSEA core -------------------------------------------------------
    n_population: int = 300          # size of P_t (mating/offspring population)
    archive_size: int = 300          # size of the Stage-1 elitist archive A_t
    max_iterations: int = 1000        # >= 100 as required
    n_runs: int = 50                 # independent runs (Run 1 .. Run 50 in the report)
    base_seed: int = 1000            # run r uses seed = base_seed + r

    # ---- variation operators -----------------------------------------------
    crossover_prob: float = 0.9      # SBX probability (per pair)
    eta_c: float = 20.0              # SBX distribution index
    mutation_prob: float = None      # None -> 1/dim (standard default)
    eta_m: float = 20.0              # polynomial mutation distribution index

    # ---- Stage 1: exploration / elitist archive -----------------------------
    grid_divisions: int = 10         # adaptive hypergrid resolution for truncation

    # ---- Stage 2: selective mating-pool construction ------------------------
    # selective_pressure blends rank_score (convergence) vs crowding_score
    # (diversity) when scoring archive members for mating-pool tournament
    # selection: 0 = pure diversity, 1 = pure convergence. It is allowed to
    # ramp linearly from `selective_pressure` (generation 1) up to
    # `selective_pressure_end` (final generation), so Stage 2 favours broad
    # exploration early and sharper exploitation late -- the run's own
    # "adaptive diversity preservation" schedule.
    selective_pressure: float = 0.5
    selective_pressure_end: float = 0.5
    adaptive_pressure: bool = False

    # ---- metrics --------------------------------------------------------
    hv_mc_samples_final: int = 60000   # Monte-Carlo samples, final HV (M >= 3)
    hv_mc_samples_history: int = 4000  # cheaper HV for the per-iteration trace
    ref_front_size: int = 1000         # points sampled from the true Pareto front
    hv_margin: float = 0.10            # reference point offset beyond the nadir

    # ---- bookkeeping ----------------------------------------------------
    history_every: int = 1           # record convergence trace every g generations
    history_metric_runs: int = 10    # how many runs feed the averaged convergence
                                     # trace (HV per generation is the expensive
                                     # part; 10 runs is ample for a smooth curve)
    results_dir: str = "results"
    figures_dir: str = "figures"
    verbose: bool = True

    # ---- problem selection ---------------------------------------------
    # ALL 27 benchmarks and nothing else: all 12 EvoPINN problems,
    # ZDT1/ZDT2/ZDT3/ZDT4/ZDT6, DTLZ1-DTLZ7, and the three Mixed min/max
    # problems. Pass --problems on the command line (or edit this list) to
    # run a subset; leave as [] to run all 27.
    problems: list = field(default_factory=lambda: [])

    def resolved_mutation_prob(self, dim):
        return (1.0 / dim) if self.mutation_prob is None else self.mutation_prob

    def resolved_selective_pressure(self, iteration, max_iterations):
        if not self.adaptive_pressure:
            return self.selective_pressure
        progress = iteration / max(1, max_iterations)
        return self.selective_pressure + progress * (self.selective_pressure_end
                                                      - self.selective_pressure)

    def ensure_dirs(self, root="."):
        root = Path(root)
        for d in (self.results_dir, self.figures_dir):
            (root / d).mkdir(parents=True, exist_ok=True)
        return root / self.results_dir, root / self.figures_dir

    def as_dict(self):
        return asdict(self)


# A small profile handy for smoke-testing the pipeline before the real run.
QUICK = DSSEAConfig(n_population=40, archive_size=40, max_iterations=10,
                    n_runs=3, hv_mc_samples_final=5000,
                    hv_mc_samples_history=1000, ref_front_size=200)

DEFAULT = DSSEAConfig()
