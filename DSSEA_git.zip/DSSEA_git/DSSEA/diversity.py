"""
diversity.py — crowding distance and the adaptively-shrinking niche
radius that give DSSEA its "selective diversity preservation".

Crowding distance (Deb-style) measures spread along each objective axis
independently, so it is direction-agnostic by construction: it only
cares about the *magnitude* of separation between neighbours in
objective space, never which direction ('min'/'max') is preferred.
That means it needs no changes at all to work correctly on mixed
minimise/maximise objective sets — the direction-sensitive work is
entirely done upstream, inside dominance.py / nondominated_sort.py.
"""

import numpy as np

from nondominated_sort import fast_nondominated_sort


def crowding_distance_per_front(F, fronts):
    """Crowding distance of every row of F, computed front-by-front.

    F      : (N, M) objective matrix
    fronts : list of index arrays, as returned by fast_nondominated_sort
    Returns: (N,) array of crowding distances (np.inf at front boundaries).
    """
    n, m = F.shape
    dist = np.zeros(n)
    for front in fronts:
        k = len(front)
        if k == 0:
            continue
        if k <= 2:
            dist[front] = np.inf
            continue
        sub = F[front]
        for j in range(m):
            order = np.argsort(sub[:, j])
            lo, hi = sub[order[0], j], sub[order[-1], j]
            span = (hi - lo) if hi > lo else 1.0
            dist[front[order[0]]] = np.inf
            dist[front[order[-1]]] = np.inf
            for pos in range(1, k - 1):
                prev_v = sub[order[pos - 1], j]
                next_v = sub[order[pos + 1], j]
                if np.isfinite(dist[front[order[pos]]]):
                    dist[front[order[pos]]] += (next_v - prev_v) / span
    return dist


def rank_and_crowding(F, objective_types):
    """Convenience wrapper: Pareto rank (0 = non-dominated) and crowding
    distance for every row of F, both mixed-direction aware via
    fast_nondominated_sort."""
    fronts = fast_nondominated_sort(F, objective_types)
    rank = np.zeros(len(F), dtype=int)
    for r, front in enumerate(fronts):
        rank[front] = r
    crowd = crowding_distance_per_front(F, fronts)
    return rank, crowd, fronts


def adaptive_niche_radius(generation, n_generations, base_radius=0.05,
                          adaptation_rate=0.5):
    """Shrinks the niche radius as the run progresses: early generations
    keep it wide (broad exploration, weak niching), later generations
    shrink it (fine-grained exploitation near the current front). This
    is the "adaptive diversity preservation" mechanism used by DSSEA's
    Stage 2 selective environmental selection (see selection.py)."""
    progress = generation / max(1, n_generations)
    return base_radius * (1.0 - adaptation_rate * progress)
