"""
optimizer.py — DSSEA (Dual-Stage Selective Evolutionary Algorithm).

Loop:

    P_0 <- random population,  A_0 <- empty
    repeat
        Stage 1 (archive.py)      : A_{t+1} <- exploration selection of
                                     P_t U A_t (non-dominated sorting +
                                     crowding distance, adaptive
                                     hypergrid truncation on overflow)
        Stage 2 (selection.py)    : score every member of A_{t+1} with
                                     the adaptively-weighted rank/
                                     crowding selective score, then run
                                     binary-tournament mating selection
                                     on that score
        P_{t+1} <- SBX crossover + polynomial mutation of the mating pool
    until t = max_iterations

Mixed minimise/maximise objective sets are supported natively: every
dominance test (inside nondominated_sort.py / dominance.py) consults
`problem['objective_types']`, and objective values are stored exactly
as the test function produced them -- nothing is ever negated.

HONESTY NOTE ON ALGORITHM FIDELITY
------------------------------------
"DSSEA" is implemented here as a fully documented, from-scratch
two-stage selection scheme built to the specification of this project
(Stage 1: exploration / elitist archive via non-dominated sorting +
crowding; Stage 2: exploitation / selective mating-pool construction
via an adaptively-weighted rank-vs-diversity score). It reuses Pareto
ranking and crowding distance as generic building blocks -- as most
elitist MOEAs do -- but Stage 2's blended, adaptively-shrinking
selective score is not part of NSGA-II, MOEA/D or SPEA2; it is this
project's own two-stage selection operator, kept separate so its
convergence/diversity trade-off (`selective_pressure`) is independently
tunable from Stage 1's elitism.
"""

import time

import numpy as np

from archive import Archive
from crossover import crossover_population
from dataset import bounds_arrays
from mutation import polynomial_mutation
from selection import selective_score, blended_score, mating_pool


class DSSEA:
    def __init__(self, problem, config, seed=0):
        self.problem = problem
        self.config = config
        self.rng = np.random.default_rng(seed)
        self.seed = seed
        self.lower, self.upper = bounds_arrays(problem)
        self.dim = problem['dim']
        self.n_obj = problem['n_obj']
        self.types = problem['objective_types']
        self.p_mut = config.resolved_mutation_prob(self.dim)
        self.n_eval = 0

    # ------------------------------------------------------------------
    def _init_population(self):
        u = self.rng.random((self.config.n_population, self.dim))
        return self.lower + u * (self.upper - self.lower)

    def _evaluate(self, X):
        f = self.problem['evaluate']
        F = np.empty((len(X), self.n_obj))
        for i, x in enumerate(X):
            F[i] = f(x)
        self.n_eval += len(X)
        return F

    def _best_per_objective(self, F):
        """Direction-aware best value of every objective (no sign flipping)."""
        out = np.empty(self.n_obj)
        for j, t in enumerate(self.types):
            out[j] = F[:, j].min() if t == 'min' else F[:, j].max()
        return out

    # ------------------------------------------------------------------
    def run(self):
        cfg = self.config
        t0 = time.perf_counter()

        archive = Archive(cfg.archive_size, self.types, grid_divisions=cfg.grid_divisions)

        X = self._init_population()
        F = self._evaluate(X)

        hist = {'iteration': [], 'archive_size': [], 'front_size': [],
                'best': [], 'mean': [], 'snapshots': []}

        for it in range(1, cfg.max_iterations + 1):
            # ---- Stage 1: exploration / elitist archive update --------
            archive.update(X, F)

            if (it % cfg.history_every == 0) or it == cfg.max_iterations:
                Ff, _ = archive.front()
                hist['iteration'].append(it)
                hist['archive_size'].append(len(archive))
                hist['front_size'].append(len(Ff))
                hist['best'].append(self._best_per_objective(archive.F))
                hist['mean'].append(archive.F.mean(axis=0))
                hist['snapshots'].append(Ff.copy())

            if it == cfg.max_iterations:
                break

            # ---- Stage 2: selective mating-pool construction -----------
            rank_score, crowd_score = selective_score(archive.F, archive.rank,
                                                       archive.crowd, self.types)
            pressure = cfg.resolved_selective_pressure(it, cfg.max_iterations)
            score = blended_score(rank_score, crowd_score, pressure)

            parents = mating_pool(archive.X, score, cfg.n_population, self.rng)
            children = crossover_population(parents, self.lower, self.upper,
                                            cfg.crossover_prob, cfg.eta_c,
                                            self.rng)
            children = polynomial_mutation(children, self.lower, self.upper,
                                           self.p_mut, cfg.eta_m, self.rng)
            X = children
            F = self._evaluate(X)

        runtime = time.perf_counter() - t0
        F_front, X_front = archive.front()

        final_rank_score, final_crowd_score = selective_score(
            archive.F, archive.rank, archive.crowd, self.types)
        final_score = blended_score(final_rank_score, final_crowd_score,
                                    cfg.selective_pressure)

        return {
            'seed': self.seed,
            'archive_decisions': archive.X,
            'archive_fitness': archive.F,
            'archive_selective_score': final_score,
            'front': F_front,
            'front_decisions': X_front,
            'runtime': runtime,
            'n_eval': self.n_eval,
            'history': hist,
        }


def run_single(problem, config, seed):
    """Convenience wrapper used by run_experiment.py."""
    return DSSEA(problem, config, seed=seed).run()
