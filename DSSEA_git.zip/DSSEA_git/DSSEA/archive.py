"""
archive.py — Stage 1 of DSSEA: exploration-oriented elitist archive.

    A_{t+1}  <-  best of  P_t U A_t

built by direction-aware fast non-dominated sorting + crowding distance
(diversity.py), exactly the elitist-environmental-selection recipe used
by most elitist MOEAs:

    1. Copy every non-dominated member of the union into A_{t+1}.
    2. If |A_{t+1}| < size : fill with the best-ranked dominated
       solutions (by rank, then crowding distance) until `size` is
       reached.
    3. If |A_{t+1}| > size : truncate the non-dominated set itself,
       repeatedly removing the individual that sits in the most
       crowded region of a self-adaptive objective-space hypergrid
       (grid extent is rebuilt from the current candidates every
       removal, so it is "adaptive" rather than a fixed static grid).

This module only builds the archive (global, exploration-oriented
selection). The second, selective stage that turns the archive into a
mating pool with an adaptively-weighted rank/diversity score lives in
selection.py — that separation of concerns is what makes DSSEA
"dual-stage".
"""

import numpy as np

from diversity import rank_and_crowding


def _hypergrid_truncate(F, keep_idx, target, divisions=10):
    """Remove members of `keep_idx` one at a time, always deleting an
    individual from the most crowded grid cell (grid rebuilt from the
    current `keep_idx` set every iteration -> adaptive extent)."""
    keep = list(keep_idx)
    while len(keep) > target:
        sub = F[keep]
        lo, hi = sub.min(axis=0), sub.max(axis=0)
        span = np.where(hi > lo, hi - lo, 1.0)
        cell = np.floor((sub - lo) / span * divisions).astype(int)
        cell = np.clip(cell, 0, divisions - 1)
        _, inverse, counts = np.unique(cell, axis=0, return_inverse=True,
                                       return_counts=True)
        crowd = counts[inverse]
        victim_local = int(np.argmax(crowd))
        keep.pop(victim_local)
    return np.array(keep, dtype=int)


class Archive:
    def __init__(self, size, objective_types, grid_divisions=10):
        self.size = size
        self.objective_types = objective_types
        self.grid_divisions = grid_divisions
        self.X = np.zeros((0, 0))
        self.F = np.zeros((0, len(objective_types)))
        self.rank = np.zeros(0, dtype=int)
        self.crowd = np.zeros(0)

    def __len__(self):
        return len(self.F)

    def update(self, X_pop, F_pop):
        """Stage 1: exploration selection of the union P_t U A_t down to
        `size` elite individuals."""
        if len(self.X) == 0:
            X_union = np.asarray(X_pop, dtype=float)
            F_union = np.asarray(F_pop, dtype=float)
        else:
            X_union = np.vstack([X_pop, self.X])
            F_union = np.vstack([F_pop, self.F])

        rank, crowd, fronts = rank_and_crowding(F_union, self.objective_types)
        nd = fronts[0] if fronts else np.array([], dtype=int)

        if len(nd) == self.size:
            sel = nd
        elif len(nd) < self.size:
            dominated = np.array([i for i in range(len(F_union)) if i not in set(nd.tolist())],
                                 dtype=int)
            if dominated.size:
                order = dominated[np.lexsort((-crowd[dominated], rank[dominated]))]
            else:
                order = dominated
            need = self.size - len(nd)
            sel = np.concatenate([nd, order[:need]])
        else:
            sel = _hypergrid_truncate(F_union, nd, self.size, self.grid_divisions)

        self.X, self.F = X_union[sel], F_union[sel]
        self.rank, self.crowd, _ = rank_and_crowding(self.F, self.objective_types)
        return rank, crowd

    def front(self):
        """Non-dominated subset of the archive (objectives, decisions)."""
        if len(self.F) == 0:
            return self.F.copy(), self.X.copy()
        mask = self.rank == 0
        return self.F[mask], self.X[mask]
