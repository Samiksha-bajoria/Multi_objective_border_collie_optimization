# SPEA2 — Multi-Objective Optimisation Suite (native min **and** max objectives)

SPEA2 (Strength Pareto Evolutionary Algorithm 2) run over **27 benchmark
problems**, with mixed minimisation/maximisation objective sets handled
*natively* — no maximisation objective is ever rewritten as `-f(x)`.

---

## Folder structure

```
SPEA2/
├── figures/                     # all PNG output (created/filled at run time)
├── results/                     # all .xlsx output (created/filled at run time)
├── venv/                        # your virtual environment (not in this bundle)
│
├── archive.py                   # external archive A_t
├── check.py                     # self-test: run this first
├── config.py                    # every parameter of the study
├── crossover.py                 # SBX crossover
├── dataset.py                   # the 27-problem registry (dims, bounds, directions)
├── density_estimation.py        # k-th nearest-neighbour density (SPEA2 D(i))
├── dominance.py                 # mixed min/max Pareto dominance
├── environmental_selection.py   # archive fill + nearest-neighbour truncation
├── evopinn_problem.py           # the 12 EvoPINN problems (your file, unchanged)
├── excel_writer.py              # workbook generation
├── fitness.py                   # SPEA2 strength / raw / total fitness
├── generate.py                  # true (expected) Pareto fronts
├── main.py                      # entry point
├── metrics.py                   # HV, IGD, GD, Spacing, Spread, Epsilon
├── mixed_test_functions.py      # Mixed_ZDT1, Mixed_DTLZ1, Mixed_DTLZ2
├── mutation.py                  # polynomial mutation
├── nondominated_sort.py         # fast non-dominated sorting
├── optimizer.py                 # the SPEA2 loop
├── README.md
├── requirements.txt
├── run_experiment.py            # 50 runs of one problem + metric aggregation
├── selection.py                 # binary tournament mating selection
├── standard_test_functions.py   # ZDT1-4, ZDT6, DTLZ1-7
└── visualization.py             # expected-vs-reality figures
```

---

## Quick start

```bash
cd SPEA2
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt

python check.py                   # verify the install + the mixed min/max logic
python main.py                    # the full study (27 problems)
```

Useful flags:

```bash
python main.py --quick                                  # 3 runs x 10 iters, seconds
python main.py --problems ZDT1 Mixed_DTLZ2              # a subset
python main.py --runs 50 --iterations 1000               # the stated minimum
python main.py --iterations 1000 --problems DTLZ3 ZDT4  # the hard multi-modal ones
python main.py --no-figures
```

**Defaults:** population 300, archive 300, **1000 iterations**, **50 independent
runs**, SBX (p=0.9, eta=20) + polynomial mutation (p=1/dim, eta=20).
1000 iterations rather than the 100 minimum because DTLZ1, DTLZ3 and ZDT4 are
strongly multi-modal and are still far from their fronts at generation 100
(you can see this yourself: `--iterations 1000` gives DTLZ1 a hypervolume of 0).
Expect roughly 1.5–2 h wall-clock for the whole sweep on one core; the twelve
EvoPINN problems dominate that budget.

---

## The 27 problems

| Family | Problems | Objectives | Directions |
|---|---|---|---|
| EvoPINN | `EvoPINN1_Poisson1D` … `EvoPINN12_Schrodinger1D` | 4 | all min |
| ZDT | ZDT1, ZDT2, ZDT3, ZDT4, ZDT6 | 2 | all min |
| DTLZ | DTLZ1 … DTLZ7 | 3 | all min |
| Mixed | Mixed_ZDT1, Mixed_DTLZ1, Mixed_DTLZ2 | 2 / 3 / 3 | **min + max** |

Each problem carries its **own** dimension and its **own per-variable bounds**
(ZDT4, for instance, uses `x1 ∈ [0,1]` with `x2..x10 ∈ [-5,5]`; the EvoPINN
dimensions are derived from the underlying network — 141 to 218 weights).

### How mixed directions are handled

`dominance.py` never transforms an objective value. For objective *j*:

* `'min'`: *a* is at least as good as *b* ⟺ `a_j <= b_j`
* `'max'`: *a* is at least as good as *b* ⟺ `a_j >= b_j`

That single rule propagates everywhere — SPEA2 strength/raw fitness,
environmental selection, front extraction, the epsilon indicator, the
hypervolume reference point, the Excel "best/worst" columns and the figure axis
labels. What the test function returns is what gets stored, plotted and
reported.

### The three mixed problems (with closed-form fronts)

| Problem | Objectives | True Pareto front |
|---|---|---|
| **Mixed_ZDT1** (dim 30) | min `f1 = x1` (cost); max `f2 = √x1 / g` (yield) | `f2 = √f1`, `f1 ∈ [0,1]` |
| **Mixed_DTLZ1** (dim 7) | min `f1, f2`; max `f3 = 0.5·x1/(1+g)` (throughput) | triangle `f3 = f1 + f2`, `f1+f2 ≤ 0.5` |
| **Mixed_DTLZ2** (dim 12) | min `f1, f2`; max `f3 = cos(πx1/2)/(1+g)` (signal) | cone `f3 = √(f1²+f2²)`, `f3 ∈ [0,1]` |

Each maximised component is a quantity that is genuinely meaningful to make
large, and it is constructed to **oppose** the minimised ones — the minimised
objectives pull `x1 → 0` while the maximised one pulls `x1 → 1`, so the
conflict is real rather than cosmetic. A plain sign flip of an existing ZDT/DTLZ
objective would have produced an aligned (degenerate) objective set with a
single ideal point, which is why the problems are built this way.
`check.py` step 4 asserts that no maximised column was sign-flipped.

---

## Excel output

`results/SPEA2_<Problem>.xlsx`, one workbook per problem. **Sheet 1 is exactly
the requested layout:**

| Run | Hypervolume | IGD | GD | Spacing | Spread | Epsilon | Runtime |
|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | 0.8452 | 0.0123 | 0.0089 | 0.043 | 0.376 | 0.021 | 1.42 |
| … | … | … | … | … | … | … | … |
| 40 | … | … | … | … | … | … | … |

Remaining sheets:

| Sheet | Contents |
|---|---|
| `Statistics` | mean / std / median / best / worst per indicator across the 40 runs |
| `Parameters` | the exact SPEA2 configuration used, incl. the HV reference point |
| `Objective_Info` | index, name, **Minimize/Maximize**, best & worst observed |
| `Iteration_History` | per-generation HV / IGD / GD / sizes and per-objective best & mean, averaged over runs |
| `Pareto_Solutions` | decision variables + objectives of the best run's front |
| `Archive` | the best run's full external archive |
| `Reference_Front` | the *expected* front (analytic, or approximated for EvoPINN) |
| `Expected_vs_Reality` | per-objective expected vs obtained best/worst and the gap |

`results/SPEA2_Master_Summary.xlsx` adds a cross-problem sheet, an all-runs dump
and the configuration.

### About the indicators

* **Hypervolume** — normalised to `[0,1]` (fraction of the reference box that is
  dominated), so values are comparable across problems. Exact for 2 objectives,
  Monte-Carlo for 3+. Directions enter through the reference point: the axis-wise
  distance is `ref_j − f_j` for a minimised objective and `f_j − ref_j` for a
  maximised one. **HV = 0 means the run never reached the reference box** — a
  genuine non-convergence signal, not a bug (DTLZ3 at 300 iterations does this).
* **GD / IGD / Spacing / Spread** — pure geometric distances, computed after
  min-max *scaling* each objective into the reference-front box. Scaling is
  essential here because the four EvoPINN losses differ by orders of magnitude;
  it changes no direction and no stored value.
* **Epsilon** — additive `I_ε+(A,R)`, direction-aware.
* All 50 runs of a problem share **one** reference front and **one** reference
  point, fixed before the runs are scored.

Reference fronts: analytic for ZDT/DTLZ/Mixed; for the twelve EvoPINN problems
no analytic front exists, so the reference set is the non-dominated union of
every run's archive (the standard fallback), reported as such in
`Parameters` and `Reference_Front`.

---

## Figures

`figures/<Problem>_front.png` — **expected vs reality**: 2-D scatter, 3-D scatter
plus projection, or (for the 4-objective EvoPINN problems) parallel coordinates
plus a log-log projection. Grey = expected reference front, red = the best run,
blue = all runs combined. Axis labels state the direction, e.g.
`f2 · Yield (MAXIMISE)`.

`figures/<Problem>_convergence.png` — mean HV / IGD / GD and archive size per
iteration.
`figures/<Problem>_distribution.png` — box plots of the six indicators over the
50 runs.
`figures/00_overview_hypervolume.png` — mean HV across all 27 problems.

---

## Algorithm summary

```
P_0 ← random population (uniform in the problem's own bounds), A_0 ← ∅
for t = 1 … max_iterations:
    U ← P_t ∪ A_t
    S(i) = |{ j ∈ U : i dominates j }|                 # mixed-direction dominance
    R(i) = Σ_{ j dominates i } S(j)
    D(i) = 1 / (σ_i^k + 2),  k = √(N + N̄)
    F(i) = R(i) + D(i)
    A_{t+1} ← { i : F(i) < 1 }
              fitness-fill if too small, nearest-neighbour truncation if too large
    mating pool ← binary tournament on F over A_{t+1}
    P_{t+1} ← polynomial_mutation( SBX( mating pool ) )
```
