"""
archive.py — the external archive A_t of SPEA2.
"""

import numpy as np

from fitness import spea2_fitness
from environmental_selection import environmental_selection
from nondominated_sort import pareto_front


class Archive:
    def __init__(self, size, objective_types, k=None, normalize_density=True):
        self.size = size
        self.objective_types = objective_types
        self.k = k
        self.normalize_density = normalize_density
        self.X = np.zeros((0, 0))
        self.F = np.zeros((0, len(objective_types)))
        self.fitness = np.zeros(0)

    def __len__(self):
        return len(self.F)

    def update(self, X_pop, F_pop):
        """One environmental-selection step: A_{t+1} <- best of P_t U A_t."""
        if len(self.X) == 0:
            X_union, F_union = np.asarray(X_pop, float), np.asarray(F_pop, float)
        else:
            X_union = np.vstack([X_pop, self.X])
            F_union = np.vstack([F_pop, self.F])

        k = self.k if self.k is not None else max(1, int(round(np.sqrt(len(F_union)))))
        info = spea2_fitness(F_union, self.objective_types,
                             k=k, normalize=self.normalize_density)
        Xa, Fa, sel = environmental_selection(X_union, F_union, info, self.size)
        self.X, self.F = Xa, Fa
        self.fitness = info['fitness'][sel]
        return info

    def front(self):
        """Non-dominated subset of the archive (objectives, decisions)."""
        if len(self.F) == 0:
            return self.F.copy(), self.X.copy()
        return pareto_front(self.F, self.X, self.objective_types)
