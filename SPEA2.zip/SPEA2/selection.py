"""
SPEA2 fills the mating pool by binary tournament *with replacement* performed
on the archive A_{t+1}, comparing total fitness F(i) (lower is better).
Because F already encodes dominance rank + density, no separate diversity
tie-break is needed.
"""

import numpy as np


def binary_tournament(fitness, n_select, rng):
    """Indices of the winners of `n_select` binary tournaments."""
    n = len(fitness)
    if n == 0:
        raise ValueError("empty archive: cannot run mating selection")
    if n == 1:
        return np.zeros(n_select, dtype=int)
    a = rng.integers(0, n, size=n_select)
    b = rng.integers(0, n, size=n_select)
    same = a == b
    if np.any(same):
        b[same] = (b[same] + 1 + rng.integers(0, n - 1, size=same.sum())) % n
    winners = np.where(fitness[a] <= fitness[b], a, b)
    return winners


def mating_pool(X_archive, fitness, pool_size, rng):
    """Decision vectors of the selected parents."""
    idx = binary_tournament(np.asarray(fitness, dtype=float), pool_size, rng)
    return X_archive[idx].copy()
