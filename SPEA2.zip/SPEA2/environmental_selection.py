"""
how SPEA2 builds A_{t+1} from P_t U A_t.

1. Copy every non-dominated member of the union (F(i) < 1) into A_{t+1}.
2. If |A_{t+1}| < N_bar : fill with the best dominated solutions, sorted by
   ascending total fitness.
3. If |A_{t+1}| > N_bar : truncate.  Repeatedly delete the individual whose
   distance to its nearest neighbour is smallest; ties are broken by the
   second-nearest neighbour, then the third, and so on.
"""

import numpy as np


def truncate(dist, keep_idx, target):
    keep = list(keep_idx)
    while len(keep) > target:
        sub = dist[np.ix_(keep, keep)]
        np.fill_diagonal(sub, np.inf)
        # sorted neighbour distances of every candidate (ascending)
        srt = np.sort(sub, axis=1)
        # lexicographic minimum: closest neighbour first, then 2nd, 3rd, ...
        order = np.lexsort(srt.T[::-1])
        victim = order[0]
        keep.pop(victim)
    return np.array(keep, dtype=int)


def environmental_selection(X_union, F_union, fit_info, archive_size):
    """
    X_union   : (N, dim)  decision vectors of P_t U A_t
    F_union   : (N, M)    raw objective values
    fit_info  : output of fitness.spea2_fitness on the same union
    Returns (X_archive, F_archive, selected_indices)
    """
    fitness = fit_info['fitness']
    dist = fit_info['dist']
    n = len(fitness)
    if n == 0:
        return X_union, F_union, np.array([], dtype=int)

    nd = np.flatnonzero(fitness < 1.0)

    if len(nd) == archive_size:
        sel = nd
    elif len(nd) < archive_size:
        dominated = np.flatnonzero(fitness >= 1.0)
        order = dominated[np.argsort(fitness[dominated], kind='stable')]
        need = archive_size - len(nd)
        sel = np.concatenate([nd, order[:need]])
    else:
        sel = truncate(dist, nd, archive_size)

    sel = np.asarray(sel, dtype=int)
    return X_union[sel], F_union[sel], sel
