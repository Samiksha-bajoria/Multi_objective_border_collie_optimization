"""
density_estimation.py — SPEA2's k-th nearest-neighbour density estimator.

    D(i) = 1 / (sigma_i^k + 2)

where sigma_i^k is the distance in objective space from solution i to its
k-th nearest neighbour, and k = sqrt(N + N_bar) by default.  

D(i) lies in (0, 0.5], so adding it to the integer raw fitness R(i) never lets a dominated
solution overtake a non-dominated one.

Note on scaling: distances are Euclidean in objective space.  Because the
EvoPINN losses can differ by several orders of magnitude between objectives, 
normalize rescales each objective to [0, 1] using the current population's
range before measuring distances.
"""

import numpy as np


def normalise(F):
    """Min-max scale each column to [0, 1]; constant columns become 0."""
    F = np.asarray(F, dtype=float)
    lo = F.min(axis=0)
    hi = F.max(axis=0)
    span = hi - lo
    span[span <= 0] = 1.0
    return (F - lo) / span


def pairwise_distances(F, normalize=True):
    """Symmetric Euclidean distance matrix in (optionally normalised) obj space."""
    G = normalise(F) if normalize else np.asarray(F, dtype=float)
    diff = G[:, None, :] - G[None, :, :]
    d = np.sqrt(np.einsum('ijk,ijk->ij', diff, diff))
    np.fill_diagonal(d, 0.0)
    return d


def kth_nearest_distance(dist, k):
    # sigma^k for every row of a distance matrix.
    n = dist.shape[0]
    if n <= 1:
        return np.zeros(n)
    k = int(min(max(k, 1), n - 1))
    part = np.sort(dist, axis=1)
    return part[:, k]


def density(F, k=None, normalize=True, dist=None):
    # SPEA2 density value D(i) for every solution
    F = np.asarray(F, dtype=float)
    n = len(F)
    if n == 0:
        return np.zeros(0)
    if dist is None:
        dist = pairwise_distances(F, normalize=normalize)
    if k is None:
        k = max(1, int(round(np.sqrt(n))))
    sigma = kth_nearest_distance(dist, k)
    return 1.0 / (sigma + 2.0)
