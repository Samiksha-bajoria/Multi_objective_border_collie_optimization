"""
For the union  U = P_t  U  A_t :

    S(i) = |{ j in U : i dominates j }|                      strength
    R(i) = sum_{ j in U, j dominates i } S(j)                raw fitness
    D(i) = 1 / (sigma_i^k + 2)                               density
    F(i) = R(i) + D(i)                                       total fitness

Lower F is better.  F(i) < 1  <=>  i is non-dominated in U.

"""

import numpy as np

from dominance import dominance_matrix
from density_estimation import density, pairwise_distances


def spea2_fitness(F_obj, objective_types, k=None, normalize=True):
    """
    Returns a dict with strength, raw, density and total fitness arrays plus
    the distance matrix
    """
    F_obj = np.asarray(F_obj, dtype=float)
    n = len(F_obj)
    if n == 0:
        empty = np.zeros(0)
        return {'strength': empty, 'raw': empty, 'density': empty,
                'fitness': empty, 'dist': np.zeros((0, 0))}

    D = dominance_matrix(F_obj, objective_types)
    strength = D.sum(axis=1).astype(float)            # i dominates how many
    raw = D.T.astype(float) @ strength

    dist = pairwise_distances(F_obj, normalize=normalize)
    if k is None:
        k = max(1, int(round(np.sqrt(n))))
    dens = density(F_obj, k=k, normalize=normalize, dist=dist)

    return {'strength': strength,
            'raw': raw,
            'density': dens,
            'fitness': raw + dens,
            'dist': dist}


def nondominated_indices_from_fitness(fitness):
    """SPEA2 shortcut: F(i) < 1 means i is non-dominated in the union."""
    return np.flatnonzero(np.asarray(fitness) < 1.0)
