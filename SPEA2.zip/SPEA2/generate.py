"""
Two kinds of reference front are produced here:

  1. `true_front_*` : closed-form fronts for ZDT, DTLZ and the three mixed
     problems.  These are the "expected" curves/surfaces plotted against the
     optimiser's actual output and used as the reference set of IGD / GD /
     Spread / Epsilon.

  2. `approximate_reference_front` : for the twelve EvoPINN problems no
     analytic front exists, so the reference set is the non-dominated union of
     every archive produced by every independent run (the standard fallback in
     the literature).
"""

import numpy as np

from nondominated_sort import pareto_front, unique_rows

def _simplex_points(n, m, rng):
    """Uniform points on the unit simplex sum(w)=1, w>=0 (Dirichlet)."""
    w = rng.dirichlet(np.ones(m), size=n)
    return w


def _sphere_points(n, m, rng):
    """Uniform-ish points on the positive octant of the unit sphere."""
    v = np.abs(rng.normal(size=(n, m)))
    return v / np.linalg.norm(v, axis=1, keepdims=True)


# ZDT family (all minimise)
def true_front_zdt1(n=1000, **kw):
    f1 = np.linspace(0.0, 1.0, n)
    return np.column_stack([f1, 1.0 - np.sqrt(f1)])


def true_front_zdt2(n=1000, **kw):
    f1 = np.linspace(0.0, 1.0, n)
    return np.column_stack([f1, 1.0 - f1 ** 2])


def true_front_zdt3(n=1000, **kw):
    f1 = np.linspace(0.0, 1.0, 5 * n)
    f2 = 1.0 - np.sqrt(f1) - f1 * np.sin(10.0 * np.pi * f1)
    F = np.column_stack([f1, f2])
    F = pareto_front(F, objective_types=['min', 'min'])
    idx = np.linspace(0, len(F) - 1, min(n, len(F))).astype(int)
    return F[idx]


def true_front_zdt4(n=1000, **kw):
    return true_front_zdt1(n)


def true_front_zdt6(n=1000, **kw):
    f1 = np.linspace(0.280775, 1.0, n)
    return np.column_stack([f1, 1.0 - f1 ** 2])


# DTLZ family (all minimise, M = 3 here)
def true_front_dtlz1(n=1000, m=3, seed=0, **kw):
    rng = np.random.default_rng(seed)
    return 0.5 * _simplex_points(n, m, rng)


def true_front_dtlz2(n=1000, m=3, seed=0, **kw):
    rng = np.random.default_rng(seed)
    return _sphere_points(n, m, rng)


true_front_dtlz3 = true_front_dtlz2
true_front_dtlz4 = true_front_dtlz2


def true_front_dtlz5(n=1000, m=3, **kw):
    """Degenerate curve: theta_2..theta_{M-1} = pi/4."""
    t1 = np.linspace(0.0, np.pi / 2, n)
    c, s = np.cos(t1), np.sin(t1)
    q = np.pi / 4
    f1 = c * np.cos(q)
    f2 = c * np.sin(q)
    f3 = s
    return np.column_stack([f1, f2, f3])


true_front_dtlz6 = true_front_dtlz5


def true_front_dtlz7(n=1000, m=3, seed=0, **kw):
    rng = np.random.default_rng(seed)
    x = rng.random((8 * n, m - 1))
    g = 1.0
    h = m - np.sum(x / (1 + g) * (1 + np.sin(3 * np.pi * x)), axis=1)
    fM = (1 + g) * h
    F = np.column_stack([x, fM])
    F = pareto_front(F, objective_types=['min'] * m)
    F, _ = unique_rows(F)
    if len(F) > n:
        idx = rng.choice(len(F), size=n, replace=False)
        F = F[idx]
    return F


# Mixed min/max problems  (see mixed_test_functions.py for the definitions)
def true_front_mixed_zdt1(n=1000, **kw):
    """min f1 = x1 ; max f2 = sqrt(x1)/g  ->  g = 1 gives f2 = sqrt(f1)."""
    f1 = np.linspace(0.0, 1.0, n)
    return np.column_stack([f1, np.sqrt(f1)])


def true_front_mixed_dtlz1(n=1000, seed=0, **kw):
    """min f1, min f2, max f3 with f3 = f1 + f2 on the plane, f1+f2 <= 0.5."""
    rng = np.random.default_rng(seed)
    w = rng.dirichlet(np.ones(2), size=n)
    s = 0.5 * rng.random(n) ** 0.5          # bias towards the outer edge
    f1 = w[:, 0] * s
    f2 = w[:, 1] * s
    return np.column_stack([f1, f2, f1 + f2])


def true_front_mixed_dtlz2(n=1000, seed=0, **kw):
    """min f1, min f2, max f3 on the cone f3 = sqrt(f1^2 + f2^2), f3 in [0,1]."""
    rng = np.random.default_rng(seed)
    phi = rng.random(n) * (np.pi / 2)
    r = rng.random(n) ** 0.5
    return np.column_stack([r * np.cos(phi), r * np.sin(phi), r])


# EvoPINN
def approximate_reference_front(list_of_F, objective_types, max_size=1000,
                               seed=0):
    """Non-dominated union of many archives — used when no analytic PF exists."""
    stacks = [np.asarray(F, dtype=float) for F in list_of_F if len(F)]
    if not stacks:
        return np.zeros((0, len(objective_types)))
    allF = np.vstack(stacks)
    allF = allF[np.all(np.isfinite(allF), axis=1)]
    if len(allF) == 0:
        return np.zeros((0, len(objective_types)))
    F = pareto_front(allF, objective_types=objective_types)
    F, _ = unique_rows(F)
    if len(F) > max_size:
        rng = np.random.default_rng(seed)
        F = F[rng.choice(len(F), size=max_size, replace=False)]
    return F


TRUE_FRONTS = {
    'ZDT1': true_front_zdt1, 'ZDT2': true_front_zdt2, 'ZDT3': true_front_zdt3,
    'ZDT4': true_front_zdt4, 'ZDT6': true_front_zdt6,
    'DTLZ1': true_front_dtlz1, 'DTLZ2': true_front_dtlz2,
    'DTLZ3': true_front_dtlz3, 'DTLZ4': true_front_dtlz4,
    'DTLZ5': true_front_dtlz5, 'DTLZ6': true_front_dtlz6,
    'DTLZ7': true_front_dtlz7,
    'Mixed_ZDT1': true_front_mixed_zdt1,
    'Mixed_DTLZ1': true_front_mixed_dtlz1,
    'Mixed_DTLZ2': true_front_mixed_dtlz2,
}
