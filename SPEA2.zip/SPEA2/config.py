# excel_writer.py and visualization.py all read from a single SPEA2Config object.
from dataclasses import dataclass, field, asdict
from pathlib import Path


@dataclass
class SPEA2Config:
    # SPEA2 core parameters
    n_population: int = 300          # size of P_t (mating population)
    archive_size: int = 300          # size of the external archive A_t
    max_iterations: int = 1000       # >= 500 as required
    n_runs: int = 50                 # >= 40 independent runs as required
    base_seed: int = 1000            # run r uses seed = base_seed + r

    # variation operators 
    crossover_prob: float = 0.9      # SBX probability (per pair)
    eta_c: float = 20.0              # SBX distribution index
    mutation_prob: float = None      # None -> 1/dim (standard default)
    eta_m: float = 20.0              # polynomial mutation distribution index

    # density / truncation
    k_neighbour: int = None          # None -> round(sqrt(N_pop + N_archive))
    normalize_density: bool = True   # normalise objective space before k-NN
                                     # (essential for EvoPINN, whose four losses differ by several orders of magnitude)

    # metrics
    hv_mc_samples_final: int = 60000   # Monte-Carlo samples, final HV (M >= 3)
    hv_mc_samples_history: int = 4000  # cheaper HV for the per-iteration trace
    ref_front_size: int = 1000         # points sampled from the true Pareto front
    hv_margin: float = 0.10            # reference point offset beyond the nadir

    # bookkeeping
    history_every: int = 1           # record convergence trace every g generations
    history_metric_runs: int = 10    # how many runs feed the averaged convergence
                                     # trace (HV per generation is the expensive
                                     # part; 10 runs is ample for a smooth curve)
    results_dir: str = "results"
    figures_dir: str = "figures"
    verbose: bool = True

    # problem selection all 27 test problems are selected by default, but the user can override with a subset.
    problems: list = field(default_factory=lambda: [])

    def resolved_mutation_prob(self, dim):
        return (1.0 / dim) if self.mutation_prob is None else self.mutation_prob

    def resolved_k(self, n_total):
        if self.k_neighbour is not None:
            return self.k_neighbour
        return max(1, int(round(n_total ** 0.5)))

    def ensure_dirs(self, root="."):
        root = Path(root)
        for d in (self.results_dir, self.figures_dir):
            (root / d).mkdir(parents=True, exist_ok=True)
        return root / self.results_dir, root / self.figures_dir

    def as_dict(self):
        return asdict(self)


# smoke-testing the pipeline before the real run.
QUICK = SPEA2Config(n_population=40, archive_size=40, max_iterations=10,
                    n_runs=3, hv_mc_samples_final=5000,
                    hv_mc_samples_history=1000, ref_front_size=200)

DEFAULT = SPEA2Config()
