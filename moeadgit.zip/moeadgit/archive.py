"""
archive.py — every non-dominated solution seen during a run,
which is what gets written to the Pareto_Solutions / Archive sheets and drawn
in the figures.  When it exceeds `size`, it is thinned by repeatedly deleting
the solution whose nearest neighbour is closest, so boundary solutions survive.

Dominance is direction-aware throughout —  dominance.py.
"""

import numpy as np

from dominance import dominance_matrix, nondominated_mask
from nondominated_sort import unique_rows


def _normalised_distances(F):
    F = np.asarray(F, dtype=float)
    lo, hi = F.min(axis=0), F.max(axis=0)
    span = hi - lo
    span[span <= 0] = 1.0
    G = (F - lo) / span
    diff = G[:, None, :] - G[None, :, :]
    d = np.sqrt(np.einsum('ijk,ijk->ij', diff, diff))
    np.fill_diagonal(d, np.inf)
    return d


def truncate(F, X, size):
    """
    The distance matrix is built once and maintained incrementally — after a
    removal only the rows whose nearest neighbour was the deleted point need
    their minimum recomputed, which keeps the whole thinning near O(n^2)
    instead of the O(n^3) a naive rebuild-every-step version costs.
    """
    n = len(F)
    if n <= size:
        return F, X
    D = _normalised_distances(F)          # diagonal is +inf
    alive = np.ones(n, dtype=bool)
    nn_dist = D.min(axis=1)
    nn_idx = D.argmin(axis=1)

    for _ in range(n - size):
        masked = np.where(alive, nn_dist, np.inf)
        victim = int(np.argmin(masked))
        alive[victim] = False
        D[victim, :] = np.inf
        D[:, victim] = np.inf
        stale = np.flatnonzero(alive & (nn_idx == victim))
        if stale.size:
            sub = D[stale]
            nn_dist[stale] = sub.min(axis=1)
            nn_idx[stale] = sub.argmin(axis=1)

    keep = np.flatnonzero(alive)
    return F[keep], X[keep]


class ExternalArchive:
    def __init__(self, size, objective_types, slack=1.5):
        self.size = size
        self.slack = slack
        self.objective_types = objective_types
        self.F = None
        self.X = None

    def __len__(self):
        return 0 if self.F is None else len(self.F)

    def add(self, X_new, F_new):
        X_new = np.atleast_2d(np.asarray(X_new, dtype=float))
        F_new = np.atleast_2d(np.asarray(F_new, dtype=float))
        ok = np.all(np.isfinite(F_new), axis=1)
        X_new, F_new = X_new[ok], F_new[ok]
        if len(F_new) == 0:
            return self

        if self.F is None:
            X_all, F_all = X_new, F_new
        else:
            X_all = np.vstack([self.X, X_new])
            F_all = np.vstack([self.F, F_new])

        mask = nondominated_mask(F_all, self.objective_types)
        F_all, X_all = F_all[mask], X_all[mask]
        F_all, keep = unique_rows(F_all)
        X_all = X_all[keep]

        # Thinning is only worth doing once the archive has drifted well past
        # its cap slack keeps the per-generation cost down without letting
        # the archive grow without bound.
        if len(F_all) > int(self.size * self.slack):
            F_all, X_all = truncate(F_all, X_all, self.size)
        self.F, self.X = F_all, X_all
        return self

    def finalise(self):
        """Enforce the exact cap once, at the end of a run."""
        if self.F is not None and len(self.F) > self.size:
            self.F, self.X = truncate(self.F, self.X, self.size)
        return self

    def front(self):
        if self.F is None:
            n_obj = len(self.objective_types)
            return np.zeros((0, n_obj)), np.zeros((0, 1))
        return self.F.copy(), self.X.copy()
