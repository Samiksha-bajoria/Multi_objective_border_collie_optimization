"""

For M = 2 the weights are simply (i/(N-1), 1 - i/(N-1)).
For M >= 3 the Das & Dennis simplex-lattice design is used: every weight is a
point of the lattice { (a_1/H, ..., a_M/H) : a_i integer >= 0, sum a_i = H },
which contains C(H+M-1, M-1) vectors.  H is chosen so that this count sits as
close as possible to the population size requested in config.py, so the actual
population size is:

    M = 2  ->  N = n_population               (100 by default)
    M = 3  ->  H = 13  ->  N = 105
    M = 4  ->  H =  6  ->  N =  84

"""

from math import comb

import numpy as np


def uniform_weights_2d(n):
    a = np.linspace(0.0, 1.0, n)
    return np.column_stack([a, 1.0 - a])


def das_dennis(H, m):
    """All lattice points with non-negative integer coordinates summing to H."""
    def rec(remaining, depth):
        if depth == m - 1:
            return [[remaining]]
        out = []
        for i in range(remaining + 1):
            for tail in rec(remaining - i, depth + 1):
                out.append([i] + tail)
        return out
    return np.array(rec(H, 0), dtype=float) / H


def choose_H(target, m):
    """Smallest-error H such that C(H+m-1, m-1) is closest to `target`."""
    best_H, best_err = 1, None
    H = 1
    while True:
        n = comb(H + m - 1, m - 1)
        err = abs(n - target)
        if best_err is None or err < best_err:
            best_H, best_err = H, err
        if n > 3 * max(target, 4):
            break
        H += 1
    return best_H


def generate_weights(n_target, m):
    """
    Returns (W, info) where W is (N, M) with rows summing to 1 and N is the
    real population size.
    """
    if m == 2:
        W = uniform_weights_2d(max(n_target, 3))
        info = {'method': 'uniform 2-D', 'H': None, 'n_weights': len(W)}
    else:
        H = choose_H(n_target, m)
        W = das_dennis(H, m)
        info = {'method': 'Das-Dennis simplex lattice', 'H': H,
                'n_weights': len(W)}
    W = np.maximum(W, 1e-6)
    W /= W.sum(axis=1, keepdims=True)
    return W, info
