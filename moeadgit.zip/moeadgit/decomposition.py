"""
decomposition.py — the scalarizing functions that turn one multi-objective
problem into N single-objective subproblems.

All three scalarizers are built on the same quantity: the *deviation from the
direction-aware ideal point*,

    d_j = | f_j - z*_j |  /  range_j                (always >= 0)

where z* is the ideal point maintained by fitness.py — the smallest value seen
so far on a MINIMISED objective, the largest value seen so far on a MAXIMISED
one.  Because the ideal already points the right way on every axis, d_j shrinks
as objective j gets better whatever its direction, and every scalarizer below
is minimised.  This is why no objective is ever multiplied by -1 anywhere in
this project.

    Tchebycheff    g = max_j  lambda_j * d_j
    Weighted sum   g = sum_j  lambda_j * d_j
    PBI            g = d1 + theta * d2
                   d1 = || d projected on lambda ||,  d2 = || d - d1*lambda_hat ||
"""

import numpy as np

METHODS = ('tchebycheff', 'weighted_sum', 'pbi')


def deviation(F, ideal, scale=None):
    """
    Direction-aware, non-negative deviation from the ideal point.
    F may be a single vector (M,) or a stack (N, M).
    """
    F = np.asarray(F, dtype=float)
    d = np.abs(F - ideal)
    if scale is not None:
        d = d / scale
    return d


def tchebycheff(d, w):
    """g = max_j w_j * d_j    (d and w broadcast over the last axis)."""
    return np.max(w * d, axis=-1)


def weighted_sum(d, w):
    """g = sum_j w_j * d_j."""
    return np.sum(w * d, axis=-1)


def pbi(d, w, theta=5.0):
    """Penalty-based boundary intersection."""
    norm = np.linalg.norm(w, axis=-1)
    norm = np.where(norm <= 0, 1e-12, norm)
    d1 = np.sum(d * w, axis=-1) / norm
    proj = d - (d1 / norm)[..., None] * w
    d2 = np.linalg.norm(proj, axis=-1)
    return d1 + theta * d2


def scalarize(F, w, ideal, method='tchebycheff', scale=None, theta=5.0):
    """One call site for the whole algorithm.  Lower is always better."""
    d = deviation(F, ideal, scale)
    if method == 'tchebycheff':
        return tchebycheff(d, w)
    if method == 'weighted_sum':
        return weighted_sum(d, w)
    if method == 'pbi':
        return pbi(d, w, theta)
    raise ValueError(f"unknown decomposition '{method}'; use one of {METHODS}")
