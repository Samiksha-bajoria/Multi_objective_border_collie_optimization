"""
EvoPINN Problems — 12 physics-informed multi-objective test problems.

Each problem: minimize [residual_loss, bc_loss, ic_loss, data_loss] jointly.
dim = actual parameter count of the underlying PINN 

"""

import numpy as np


class TanhMLP:
    def __init__(self, layer_sizes):
        self.layer_sizes = layer_sizes
        self.n_params = sum(
            layer_sizes[i] * layer_sizes[i + 1] + layer_sizes[i + 1]
            for i in range(len(layer_sizes) - 1)
        )

    def unpack(self, theta):
        Ws, bs, idx = [], [], 0
        for i in range(len(self.layer_sizes) - 1):
            n_in, n_out = self.layer_sizes[i], self.layer_sizes[i + 1]
            w_size = n_in * n_out
            W = theta[idx: idx + w_size].reshape(n_out, n_in); idx += w_size
            b = theta[idx: idx + n_out]; idx += n_out
            Ws.append(W); bs.append(b)
        return Ws, bs

    def forward(self, theta, X):
        Ws, bs = self.unpack(theta)
        a = X
        for l, (W, b) in enumerate(zip(Ws, bs)):
            z = a @ W.T + b
            a = np.tanh(z) if l < len(Ws) - 1 else z
        return a

    def forward_with_derivs(self, theta, X, deriv_dims):
        Ws, bs = self.unpack(theta)
        N, n_in = X.shape
        cur_first = {d: np.zeros((N, n_in)) for d in deriv_dims}
        for d in deriv_dims:
            cur_first[d][:, d] = 1.0
        cur_second = {d: np.zeros((N, n_in)) for d in deriv_dims if deriv_dims[d] >= 2}
        a = X
        for l, (W, b) in enumerate(zip(Ws, bs)):
            z = a @ W.T + b
            z_first = {d: cur_first[d] @ W.T for d in deriv_dims}
            z_second = {d: cur_second[d] @ W.T for d in cur_second}
            if l == len(Ws) - 1:
                a = z
                cur_first, cur_second = z_first, z_second
            else:
                t = np.tanh(z)
                sech2 = 1 - t**2
                tanh_dbl = -2 * t * sech2
                new_first = {d: sech2 * z_first[d] for d in deriv_dims}
                new_second = {d: tanh_dbl * z_first[d]**2 + sech2 * z_second[d]
                              for d in cur_second}
                a = t
                cur_first, cur_second = new_first, new_second
        derivs = {(d, 1): cur_first[d] for d in deriv_dims}
        derivs.update({(d, 2): cur_second[d] for d in cur_second})
        return a, derivs


def mse(a, b=0.0):
    return float(np.mean((a - b) ** 2))


def rk4_integrate(f, y0, t0, t1, n_steps):
    ts = np.linspace(t0, t1, n_steps + 1)
    h = ts[1] - ts[0]
    ys = np.zeros((n_steps + 1, len(y0)))
    y = np.array(y0, dtype=float)
    ys[0] = y
    for i in range(n_steps):
        t = ts[i]
        k1 = f(t, y)
        k2 = f(t + h / 2, y + h / 2 * k1)
        k3 = f(t + h / 2, y + h / 2 * k2)
        k4 = f(t + h, y + h * k3)
        y = y + (h / 6) * (k1 + 2 * k2 + 2 * k3 + k4)
        ys[i + 1] = y
    return ts, ys


def unif(rng, lo, hi, n, d=1):
    return rng.uniform(lo, hi, size=(n, d))


class EvoPINNProblem:
    def __init__(self, name, net_layers, seed=0, param_bounds=(-2.0, 2.0)):
        self.name = name
        self.rng = np.random.default_rng(seed)
        self.net = TanhMLP(net_layers)
        self.n_obj = 4  # residual, bc, ic, data — fixed across all 12
        self.dim = self.net.n_params  # DERIVED, not assigned
        self.bounds = [param_bounds] * self.dim
        self.objective_types = ['min'] * self.n_obj
        self._build_data()

    def _build_data(self):
        raise NotImplementedError

    def evaluate(self, x):
        return self._objectives(np.asarray(x))

    def _objectives(self, theta):
        raise NotImplementedError


class EvoPINN1_Poisson1D(EvoPINNProblem):
    def __init__(self, seed=0):
        super().__init__("EvoPINN1_Poisson1D", [1, 10, 10, 1], seed)

    def _build_data(self):
        r = self.rng
        self.Xr = unif(r, 0, 1, 100)
        self.Xb = np.array([[0.0], [1.0]])
        self.ub = np.sin(np.pi * self.Xb) + 0.5 * self.Xb**2
        self.Xd = unif(r, 0, 1, 10)
        self.ud = np.sin(np.pi * self.Xd) + 0.5 * self.Xd**2

    @staticmethod
    def f(x):
        return -np.pi**2 * np.sin(np.pi * x) + 1.0

    def _objectives(self, theta):
        _, d = self.net.forward_with_derivs(theta, self.Xr, {0: 2})
        r = d[(0, 2)] - self.f(self.Xr)
        L_r = mse(r)
        L_bc = mse(self.net.forward(theta, self.Xb), self.ub)
        L_ic = 0.0
        L_d = mse(self.net.forward(theta, self.Xd), self.ud)
        return np.array([L_r, L_bc, L_ic, L_d])


class EvoPINN2_Heat1D(EvoPINNProblem):
    alpha = 0.1

    def __init__(self, seed=1):
        super().__init__("EvoPINN2_Heat1D", [2, 10, 10, 1], seed)

    def _build_data(self):
        r = self.rng
        self.Xr = np.hstack([unif(r, 0, 1, 100), unif(r, 0, 1, 100)])
        tb = unif(r, 0, 1, 20)
        self.Xb = np.vstack([np.hstack([np.zeros_like(tb), tb]),
                              np.hstack([np.ones_like(tb), tb])])
        self.ub = np.zeros((self.Xb.shape[0], 1))
        x0 = unif(r, 0, 1, 20)
        self.X0 = np.hstack([x0, np.zeros_like(x0)])
        self.u0 = np.sin(np.pi * x0)
        self.Xd = np.hstack([unif(r, 0, 1, 10), unif(r, 0, 1, 10)])
        self.ud = self._exact(self.Xd)

    def _exact(self, X):
        x, t = X[:, :1], X[:, 1:]
        return np.exp(-self.alpha * np.pi**2 * t) * np.sin(np.pi * x)

    def _objectives(self, theta):
        _, d = self.net.forward_with_derivs(theta, self.Xr, {0: 2, 1: 1})
        r = d[(1, 1)] - self.alpha * d[(0, 2)]
        L_r = mse(r)
        L_bc = mse(self.net.forward(theta, self.Xb), self.ub)
        L_ic = mse(self.net.forward(theta, self.X0), self.u0)
        L_d = mse(self.net.forward(theta, self.Xd), self.ud)
        return np.array([L_r, L_bc, L_ic, L_d])


class EvoPINN3_Advection1D(EvoPINNProblem):
    c = 1.0

    def __init__(self, seed=2):
        super().__init__("EvoPINN3_Advection1D", [2, 10, 10, 1], seed)

    def _build_data(self):
        r = self.rng
        self.Xr = np.hstack([unif(r, 0, 2 * np.pi, 100), unif(r, 0, 1, 100)])
        tb = unif(r, 0, 1, 20)
        self.Xb = np.vstack([np.hstack([np.zeros_like(tb), tb]),
                              np.hstack([np.full_like(tb, 2 * np.pi), tb])])
        self.ub = self._exact(self.Xb)
        x0 = unif(r, 0, 2 * np.pi, 20)
        self.X0 = np.hstack([x0, np.zeros_like(x0)])
        self.u0 = np.sin(x0)
        self.Xd = np.hstack([unif(r, 0, 2 * np.pi, 10), unif(r, 0, 1, 10)])
        self.ud = self._exact(self.Xd)

    def _exact(self, X):
        x, t = X[:, :1], X[:, 1:]
        return np.sin(x - self.c * t)

    def _objectives(self, theta):
        _, d = self.net.forward_with_derivs(theta, self.Xr, {0: 1, 1: 1})
        r = d[(1, 1)] + self.c * d[(0, 1)]
        L_r = mse(r)
        L_bc = mse(self.net.forward(theta, self.Xb), self.ub)
        L_ic = mse(self.net.forward(theta, self.X0), self.u0)
        L_d = mse(self.net.forward(theta, self.Xd), self.ud)
        return np.array([L_r, L_bc, L_ic, L_d])


class EvoPINN4_Wave1D(EvoPINNProblem):
    c = 1.0

    def __init__(self, seed=3):
        super().__init__("EvoPINN4_Wave1D", [2, 10, 10, 1], seed)

    def _build_data(self):
        r = self.rng
        self.Xr = np.hstack([unif(r, 0, 1, 100), unif(r, 0, 1, 100)])
        tb = unif(r, 0, 1, 20)
        self.Xb = np.vstack([np.hstack([np.zeros_like(tb), tb]),
                              np.hstack([np.ones_like(tb), tb])])
        self.ub = np.zeros((self.Xb.shape[0], 1))
        self.x0 = unif(r, 0, 1, 20)
        self.X0 = np.hstack([self.x0, np.zeros_like(self.x0)])
        self.u0_val = np.sin(np.pi * self.x0)
        self.u0_vel = np.zeros_like(self.x0)
        self.Xd = np.hstack([unif(r, 0, 1, 10), unif(r, 0, 1, 10)])
        self.ud = self._exact(self.Xd)

    def _exact(self, X):
        x, t = X[:, :1], X[:, 1:]
        return np.sin(np.pi * x) * np.cos(np.pi * self.c * t)

    def _objectives(self, theta):
        _, d = self.net.forward_with_derivs(theta, self.Xr, {0: 2, 1: 2})
        r = d[(1, 2)] - self.c**2 * d[(0, 2)]
        L_r = mse(r)
        L_bc = mse(self.net.forward(theta, self.Xb), self.ub)
        _, d0 = self.net.forward_with_derivs(theta, self.X0, {1: 1})
        u0_pred = self.net.forward(theta, self.X0)
        L_ic = 0.5 * mse(u0_pred, self.u0_val) + 0.5 * mse(d0[(1, 1)], self.u0_vel)
        L_d = mse(self.net.forward(theta, self.Xd), self.ud)
        return np.array([L_r, L_bc, L_ic, L_d])


class EvoPINN5_Burgers1D(EvoPINNProblem):
    nu = 0.01 / np.pi

    def __init__(self, seed=4):
        super().__init__("EvoPINN5_Burgers1D", [2, 10, 10, 1], seed)

    def _build_data(self):
        r = self.rng
        self.Xr = np.hstack([unif(r, 0, 1, 100), unif(r, 0, 1, 100)])
        tb = unif(r, 0, 1, 20)
        self.Xb = np.vstack([np.hstack([np.zeros_like(tb), tb]),
                              np.hstack([np.ones_like(tb), tb])])
        self.ub = np.zeros((self.Xb.shape[0], 1))
        x0 = unif(r, 0, 1, 20)
        self.X0 = np.hstack([x0, np.zeros_like(x0)])
        self.u0 = np.sin(np.pi * x0)
        self.Xd = np.hstack([unif(r, 0, 1, 10), unif(r, 0, 1, 10)])
        self.ud = self._exact(self.Xd)

    def _exact(self, X):
        x, t = X[:, :1], X[:, 1:]
        return np.sin(np.pi * x) * np.exp(-t)

    def _f(self, X):
        x, t = X[:, :1], X[:, 1:]
        u = self._exact(X)
        return u * (self.nu * np.pi**2 - 1.0) + 0.5 * np.pi * np.sin(2 * np.pi * x) * np.exp(-2 * t)

    def _objectives(self, theta):
        u, d = self.net.forward_with_derivs(theta, self.Xr, {0: 2, 1: 1})
        r = d[(1, 1)] + u * d[(0, 1)] - self.nu * d[(0, 2)] - self._f(self.Xr)
        L_r = mse(r)
        L_bc = mse(self.net.forward(theta, self.Xb), self.ub)
        L_ic = mse(self.net.forward(theta, self.X0), self.u0)
        L_d = mse(self.net.forward(theta, self.Xd), self.ud)
        return np.array([L_r, L_bc, L_ic, L_d])


class EvoPINN6_AllenCahn1D(EvoPINNProblem):
    d_coef = 0.1

    def __init__(self, seed=5):
        super().__init__("EvoPINN6_AllenCahn1D", [2, 10, 10, 1], seed)

    def _build_data(self):
        r = self.rng
        self.Xr = np.hstack([unif(r, -1, 1, 100), unif(r, 0, 1, 100)])
        tb = unif(r, 0, 1, 20)
        self.Xb = np.vstack([np.hstack([-np.ones_like(tb), tb]),
                              np.hstack([np.ones_like(tb), tb])])
        self.ub = np.zeros((self.Xb.shape[0], 1))
        x0 = unif(r, -1, 1, 20)
        self.X0 = np.hstack([x0, np.zeros_like(x0)])
        self.u0 = np.sin(np.pi * x0)
        self.Xd = np.hstack([unif(r, -1, 1, 10), unif(r, 0, 1, 10)])
        self.ud = self._exact(self.Xd)

    def _exact(self, X):
        x, t = X[:, :1], X[:, 1:]
        return np.sin(np.pi * x) * np.exp(-t)

    def _f(self, X):
        u = self._exact(X)
        return u * (self.d_coef * np.pi**2 - 2.0) + u**3

    def _objectives(self, theta):
        u, d = self.net.forward_with_derivs(theta, self.Xr, {0: 2, 1: 1})
        r = d[(1, 1)] - self.d_coef * d[(0, 2)] - u + u**3 - self._f(self.Xr)
        L_r = mse(r)
        L_bc = mse(self.net.forward(theta, self.Xb), self.ub)
        L_ic = mse(self.net.forward(theta, self.X0), self.u0)
        L_d = mse(self.net.forward(theta, self.Xd), self.ud)
        return np.array([L_r, L_bc, L_ic, L_d])


class EvoPINN7_Poisson2D(EvoPINNProblem):
    def __init__(self, seed=6):
        super().__init__("EvoPINN7_Poisson2D", [2, 10, 10, 1], seed)

    def _build_data(self):
        r = self.rng
        self.Xr = np.hstack([unif(r, 0, 1, 150), unif(r, 0, 1, 150)])
        edge = unif(r, 0, 1, 20)
        z, o = np.zeros_like(edge), np.ones_like(edge)
        self.Xb = np.vstack([np.hstack([z, edge]), np.hstack([o, edge]),
                              np.hstack([edge, z]), np.hstack([edge, o])])
        self.ub = np.zeros((self.Xb.shape[0], 1))
        self.Xd = np.hstack([unif(r, 0, 1, 10), unif(r, 0, 1, 10)])
        self.ud = self._exact(self.Xd)

    def _exact(self, X):
        x, y = X[:, :1], X[:, 1:]
        return np.sin(np.pi * x) * np.sin(np.pi * y)

    def _f(self, X):
        return -2 * np.pi**2 * self._exact(X)

    def _objectives(self, theta):
        _, d = self.net.forward_with_derivs(theta, self.Xr, {0: 2, 1: 2})
        r = d[(0, 2)] + d[(1, 2)] - self._f(self.Xr)
        L_r = mse(r)
        L_bc = mse(self.net.forward(theta, self.Xb), self.ub)
        L_ic = 0.0
        L_d = mse(self.net.forward(theta, self.Xd), self.ud)
        return np.array([L_r, L_bc, L_ic, L_d])


class EvoPINN8_ReactionDiffusion1D(EvoPINNProblem):
    D, k = 0.05, 1.0

    def __init__(self, seed=7):
        super().__init__("EvoPINN8_ReactionDiffusion1D", [2, 10, 10, 1], seed)

    def _build_data(self):
        r = self.rng
        self.Xr = np.hstack([unif(r, 0, 1, 100), unif(r, 0, 1, 100)])
        tb = unif(r, 0, 1, 20)
        self.Xb = np.vstack([np.hstack([np.zeros_like(tb), tb]),
                              np.hstack([np.ones_like(tb), tb])])
        self.ub = np.zeros((self.Xb.shape[0], 1))
        x0 = unif(r, 0, 1, 20)
        self.X0 = np.hstack([x0, np.zeros_like(x0)])
        self.u0 = np.sin(np.pi * x0)
        self.Xd = np.hstack([unif(r, 0, 1, 10), unif(r, 0, 1, 10)])
        self.ud = self._exact(self.Xd)

    def _exact(self, X):
        x, t = X[:, :1], X[:, 1:]
        return np.sin(np.pi * x) * np.exp(-t)

    def _f(self, X):
        u = self._exact(X)
        return u * (self.D * np.pi**2 - 1.0 - self.k) + self.k * u**2

    def _objectives(self, theta):
        u, d = self.net.forward_with_derivs(theta, self.Xr, {0: 2, 1: 1})
        r = d[(1, 1)] - self.D * d[(0, 2)] - self.k * u * (1 - u) - self._f(self.Xr)
        L_r = mse(r)
        L_bc = mse(self.net.forward(theta, self.Xb), self.ub)
        L_ic = mse(self.net.forward(theta, self.X0), self.u0)
        L_d = mse(self.net.forward(theta, self.Xd), self.ud)
        return np.array([L_r, L_bc, L_ic, L_d])


class EvoPINN9_DampedOscillator(EvoPINNProblem):
    zeta, w = 0.2, 2 * np.pi

    def __init__(self, seed=8):
        super().__init__("EvoPINN9_DampedOscillator", [1, 10, 10, 1], seed)

    def _build_data(self):
        self.wd = self.w * np.sqrt(1 - self.zeta**2)
        r = self.rng
        self.Tr = unif(r, 0, 4, 100)
        self.T0 = np.array([[0.0]])
        self.Td = unif(r, 0, 4, 10)
        self.ud = self._exact(self.Td)

    def _exact(self, T):
        z, w, wd = self.zeta, self.w, self.wd
        return np.exp(-z * w * T) * (np.cos(wd * T) + (z * w / wd) * np.sin(wd * T))

    def _objectives(self, theta):
        _, d = self.net.forward_with_derivs(theta, self.Tr, {0: 2})
        r = d[(0, 2)] + 2 * self.zeta * self.w * d[(0, 1)] + self.w**2 * self.net.forward(theta, self.Tr)
        L_r = mse(r)
        u0 = self.net.forward(theta, self.T0)
        _, d0 = self.net.forward_with_derivs(theta, self.T0, {0: 1})
        L_bc = mse(u0, 1.0)
        L_ic = mse(d0[(0, 1)], 0.0)
        L_d = mse(self.net.forward(theta, self.Td), self.ud)
        return np.array([L_r, L_bc, L_ic, L_d])


class EvoPINN10_VanDerPol(EvoPINNProblem):
    mu = 1.0

    def __init__(self, seed=9):
        super().__init__("EvoPINN10_VanDerPol", [1, 10, 10, 1], seed)

    def _build_data(self):
        r = self.rng
        self.Tr = unif(r, 0, 10, 150)
        self.T0 = np.array([[0.0]])

        def rhs(t, y):
            u, v = y
            return np.array([v, self.mu * (1 - u**2) * v - u])

        ts, ys = rk4_integrate(rhs, [2.0, 0.0], 0.0, 10.0, 2000)
        idx = self.rng.choice(len(ts), size=10, replace=False)
        self.Td = ts[idx].reshape(-1, 1)
        self.ud = ys[idx, 0].reshape(-1, 1)

    def _objectives(self, theta):
        u, d = self.net.forward_with_derivs(theta, self.Tr, {0: 2})
        r = d[(0, 2)] - self.mu * (1 - u**2) * d[(0, 1)] + u
        L_r = mse(r)
        u0 = self.net.forward(theta, self.T0)
        _, d0 = self.net.forward_with_derivs(theta, self.T0, {0: 1})
        L_bc = mse(u0, 2.0)
        L_ic = mse(d0[(0, 1)], 0.0)
        L_d = mse(self.net.forward(theta, self.Td), self.ud)
        return np.array([L_r, L_bc, L_ic, L_d])


class EvoPINN11_LotkaVolterra(EvoPINNProblem):
    a, b, c, d_ = 1.1, 0.4, 0.4, 0.1

    def __init__(self, seed=10):
        super().__init__("EvoPINN11_LotkaVolterra", [1, 10, 10, 2], seed)

    def _build_data(self):
        r = self.rng
        self.Tr = unif(r, 0, 20, 200)
        self.T0 = np.array([[0.0]])
        self.y0 = np.array([10.0, 5.0])

        def rhs(t, y):
            x, yy = y
            return np.array([self.a * x - self.b * x * yy,
                              -self.c * yy + self.d_ * x * yy])

        ts, ys = rk4_integrate(rhs, self.y0, 0.0, 20.0, 4000)
        idx = self.rng.choice(len(ts), size=15, replace=False)
        self.Td = ts[idx].reshape(-1, 1)
        self.yd = ys[idx]
        self.H0 = (self.d_ * self.y0[0] - self.c * np.log(self.y0[0])
                   + self.b * self.y0[1] - self.a * np.log(self.y0[1]))

    def _objectives(self, theta):
        u, d = self.net.forward_with_derivs(theta, self.Tr, {0: 1})
        x, y = u[:, :1], u[:, 1:]
        xt, yt = d[(0, 1)][:, :1], d[(0, 1)][:, 1:]
        rx = xt - (self.a * x - self.b * x * y)
        ry = yt - (-self.c * y + self.d_ * x * y)
        L_r = 0.5 * (mse(rx) + mse(ry))
        u0 = self.net.forward(theta, self.T0)[0]
        L_bc = 0.5 * ((u0[0] - self.y0[0])**2 + (u0[1] - self.y0[1])**2)
        x_pos = np.clip(x, 1e-3, None); y_pos = np.clip(y, 1e-3, None)
        H = self.d_ * x_pos - self.c * np.log(x_pos) + self.b * y_pos - self.a * np.log(y_pos)
        L_ic = mse(H, self.H0)
        L_d = mse(self.net.forward(theta, self.Td), self.yd)
        return np.array([L_r, L_bc, L_ic, L_d])


class EvoPINN12_Schrodinger1D(EvoPINNProblem):
    E0 = 0.5

    def __init__(self, seed=11):
        super().__init__("EvoPINN12_Schrodinger1D", [2, 12, 12, 2], seed)

    def _build_data(self):
        r = self.rng
        self.Xr = np.hstack([unif(r, -5, 5, 150), unif(r, 0, 1, 150)])
        tb = unif(r, 0, 1, 20)
        self.Xb = np.vstack([np.hstack([-5 * np.ones_like(tb), tb]),
                              np.hstack([5 * np.ones_like(tb), tb])])
        self.ub = np.zeros((self.Xb.shape[0], 2))
        x0 = unif(r, -5, 5, 20)
        self.X0 = np.hstack([x0, np.zeros_like(x0)])
        self.u0 = np.hstack([self._phi0(x0), np.zeros_like(x0)])
        self.Xd = np.hstack([unif(r, -5, 5, 10), unif(r, 0, 1, 10)])
        self.ud = self._exact(self.Xd)

    @staticmethod
    def _phi0(x):
        return np.pi**-0.25 * np.exp(-x**2 / 2)

    def _exact(self, X):
        x, t = X[:, :1], X[:, 1:]
        phi0 = self._phi0(x)
        return np.hstack([phi0 * np.cos(self.E0 * t), -phi0 * np.sin(self.E0 * t)])

    def _objectives(self, theta):
        w, d = self.net.forward_with_derivs(theta, self.Xr, {0: 2, 1: 1})
        u, v = w[:, :1], w[:, 1:]
        ux2, vx2 = d[(0, 2)][:, :1], d[(0, 2)][:, 1:]
        ut, vt = d[(1, 1)][:, :1], d[(1, 1)][:, 1:]
        V = 0.5 * self.Xr[:, :1]**2
        r_real = -vt + 0.5 * ux2 - V * u
        r_imag = ut + 0.5 * vx2 - V * v
        L_r = 0.5 * (mse(r_real) + mse(r_imag))
        L_bc = mse(self.net.forward(theta, self.Xb), self.ub)
        L_ic = mse(self.net.forward(theta, self.X0), self.u0)
        L_d = mse(self.net.forward(theta, self.Xd), self.ud)
        return np.array([L_r, L_bc, L_ic, L_d])


_PROBLEM_CLASSES = [
    EvoPINN1_Poisson1D, EvoPINN2_Heat1D, EvoPINN3_Advection1D,
    EvoPINN4_Wave1D, EvoPINN5_Burgers1D, EvoPINN6_AllenCahn1D,
    EvoPINN7_Poisson2D, EvoPINN8_ReactionDiffusion1D,
    EvoPINN9_DampedOscillator, EvoPINN10_VanDerPol,
    EvoPINN11_LotkaVolterra, EvoPINN12_Schrodinger1D,
]

evopinn_problems = {cls.__name__.split("_", 1)[0]: cls() for cls in _PROBLEM_CLASSES}


def get_evopinn_problem(name):
    return evopinn_problems.get(name, evopinn_problems['EvoPINN1'])


def get_all_evopinn_problems():
    return evopinn_problems


def create_mixed_evopinn_problems():
    """
    All 4 objectives here are already independent MSE-style quantities;
    none is arbitrarily forced to 'max'. If your MOBCO/NSGA2 code needs
    a genuine mixed min/max test case, that requires a deliberate design
    choice (not flipping a physics-error term's sign), so verify with
    your other files (mobco_main.py, run_mobco.py) what they expect
    before relying on this function.
    """
    return get_all_evopinn_problems()

    