import numpy as np


def mating_indices(i, B, n_pop, delta, rng, k=2):
    """Pool of candidate indices for subproblem i, and the pool it may replace."""
    pool = B[i] if rng.random() < delta else np.arange(n_pop)
    n = len(pool)
    a = int(rng.integers(n))
    b = int(rng.integers(n))
    if b == a and n > 1:
        b = (b + 1 + int(rng.integers(n - 1))) % n
    picks = pool[[a, b][:max(1, min(k, n))]]
    return picks, pool


def replacement_order(pool, rng):
    """MOEA/D replaces neighbours in random order, capped at nr successes."""
    order = np.array(pool, dtype=int)
    rng.shuffle(order)
    return order
