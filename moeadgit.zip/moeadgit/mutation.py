
import numpy as np


def polynomial_mutation(X, lower, upper, prob, eta=20.0, rng=None):
    """Vectorised polynomial mutation over a whole population."""
    rng = np.random.default_rng() if rng is None else rng
    Y = np.asarray(X, dtype=float).copy()
    n, d = Y.shape

    do = rng.random((n, d)) <= prob
    span = (upper - lower)[None, :]
    span = np.where(span <= 0, 1e-14, span)

    delta1 = (Y - lower[None, :]) / span
    delta2 = (upper[None, :] - Y) / span
    u = rng.random((n, d))
    mut_pow = 1.0 / (eta + 1.0)

    lower_branch = u <= 0.5
    xy = np.where(lower_branch, 1.0 - delta1, 1.0 - delta2)
    val = np.where(lower_branch,
                   2.0 * u + (1.0 - 2.0 * u) * xy ** (eta + 1.0),
                   2.0 * (1.0 - u) + 2.0 * (u - 0.5) * xy ** (eta + 1.0))
    deltaq = np.where(lower_branch,
                      val ** mut_pow - 1.0,
                      1.0 - val ** mut_pow)

    Y = np.where(do, Y + deltaq * span, Y)
    return np.clip(Y, lower[None, :], upper[None, :])
