"""
fitness.py — the reference points of MOEA/D and the subproblem fitness values.

`ReferencePoint` maintains, per objective and in that objective's OWN
direction:

    ideal z*_j    the best value seen so far
                  (minimum for 'min', maximum for 'max')
    nadir z^nad_j the worst value seen so far
                  (maximum for 'min', minimum for 'max')

The nadir is only used as a normalisation scale, so that a Tchebycheff or PBI
value is not dominated by whichever objective happens to have the largest
magnitude.  That matters a lot here: the four EvoPINN losses routinely span
several orders of magnitude, and without normalisation the residual loss alone
would decide every scalarized comparison.

No objective value is ever rewritten; the direction is applied when deciding
which end of the observed range counts as "best".
"""

import numpy as np

from decomposition import scalarize
from dominance import min_mask


class ReferencePoint:
    def __init__(self, objective_types):
        self.mins = min_mask(objective_types)
        self.ideal = np.where(self.mins, np.inf, -np.inf).astype(float)
        self.nadir = np.where(self.mins, -np.inf, np.inf).astype(float)
        self._scale_cache = None

    def update(self, F):
        """Absorb one solution (M,) or a stack (N, M)."""
        F = np.atleast_2d(np.asarray(F, dtype=float))
        F = F[np.all(np.isfinite(F), axis=1)]
        if len(F) == 0:
            return self
        col_min = F.min(axis=0)
        col_max = F.max(axis=0)
        best = np.where(self.mins, col_min, col_max)
        worst = np.where(self.mins, col_max, col_min)
        self.ideal = np.where(self.mins,
                              np.minimum(self.ideal, best),
                              np.maximum(self.ideal, best))
        self.nadir = np.where(self.mins,
                              np.maximum(self.nadir, worst),
                              np.minimum(self.nadir, worst))
        self._scale_cache = None
        return self

    def scale(self, normalize=True):
        """Per-objective normalisation range; 1.0 when normalisation is off."""
        if not normalize:
            return np.ones_like(self.ideal)
        if self._scale_cache is None:
            rng = np.abs(self.nadir - self.ideal)
            self._scale_cache = np.where(np.isfinite(rng) & (rng > 1e-12),
                                         rng, 1.0)
        return self._scale_cache


def subproblem_fitness(F, w, ref, method='tchebycheff', theta=5.0,
                       normalize=True):
    """Scalarized value of solution(s) F on the subproblem with weight w."""
    return scalarize(F, w, ref.ideal, method=method,
                     scale=ref.scale(normalize), theta=theta)


def is_improvement(f_new, f_old, w, ref, method='tchebycheff', theta=5.0,
                   normalize=True):
    """True if f_new is at least as good as f_old on that subproblem."""
    g_new = subproblem_fitness(f_new, w, ref, method, theta, normalize)
    g_old = subproblem_fitness(f_old, w, ref, method, theta, normalize)
    return bool(g_new <= g_old)
