"""
optimizer.py — MOEA/D (Multi-Objective Evolutionary Algorithm based on
Decomposition), Zhang & Li 2007, with the Li & Zhang 2009 refinements
(neighbourhood-vs-population mating controlled by `delta`, replacement capped
at `nr`).

Loop:

    generate N uniformly spread weight vectors  ->  N subproblems
    B(i) <- the T nearest weight vectors of lambda^i
    P    <- random population, one solution per subproblem
    z*   <- direction-aware ideal point of P
    repeat
        for every subproblem i:
            pool     <- B(i) with probability delta, else the whole population
            child    <- polynomial_mutation( SBX( two parents from pool ) )
            evaluate child, update z* and the nadir estimate
            for at most nr members j of pool, in random order:
                if g(child | lambda^j, z*) <= g(x_j | lambda^j, z*):
                    x_j <- child
        push this generation's children into the external archive
    until max_iterations

Mixed minimise/maximise objective sets are supported natively: the ideal point
is tracked per objective in that objective's own direction, the scalarizers act
on |f - z*| (see decomposition.py), and every dominance test consults
`problem['objective_types']`.  No objective is ever multiplied by -1.
"""

import time

import numpy as np

from archive import ExternalArchive
from crossover import sbx
from dataset import bounds_arrays
from decomposition import METHODS
from fitness import ReferencePoint, subproblem_fitness
from mutation import polynomial_mutation
from neighborhood import compute_neighborhoods
from nondominated_sort import pareto_front
from selection import mating_indices, replacement_order
from weight_vectors import generate_weights


class MOEAD:
    def __init__(self, problem, config, seed=0):
        if config.decomposition not in METHODS:
            raise ValueError(f"decomposition must be one of {METHODS}")
        self.problem = problem
        self.config = config
        self.rng = np.random.default_rng(seed)
        self.seed = seed
        self.lower, self.upper = bounds_arrays(problem)
        self.dim = problem['dim']
        self.n_obj = problem['n_obj']
        self.types = problem['objective_types']
        self.p_mut = config.resolved_mutation_prob(self.dim)
        self.n_eval = 0

        self.W, self.weight_info = generate_weights(config.n_population, self.n_obj)
        self.n_pop = len(self.W)
        self.B = compute_neighborhoods(self.W, config.T)

    # ------------------------------------------------------------------
    def _evaluate(self, x):
        self.n_eval += 1
        return np.asarray(self.problem['evaluate'](x), dtype=float)

    def _evaluate_many(self, X):
        F = np.empty((len(X), self.n_obj))
        for i, x in enumerate(X):
            F[i] = self._evaluate(x)
        return F

    def _best_per_objective(self, F):
        """Direction-aware best value of every objective (no sign flipping)."""
        out = np.empty(self.n_obj)
        for j, t in enumerate(self.types):
            out[j] = F[:, j].min() if t == 'min' else F[:, j].max()
        return out

    def _g(self, F, w, ref):
        cfg = self.config
        return subproblem_fitness(F, w, ref, cfg.decomposition, cfg.pbi_theta,
                                  cfg.normalize_scalarizer)

    # ------------------------------------------------------------------
    def run(self):
        cfg = self.config
        t0 = time.perf_counter()
        rng = self.rng

        # --- initialisation ------------------------------------------------
        u = rng.random((self.n_pop, self.dim))
        X = self.lower + u * (self.upper - self.lower)
        F = self._evaluate_many(X)

        ref = ReferencePoint(self.types).update(F)
        archive = ExternalArchive(cfg.archive_size, self.types)
        archive.add(X, F)

        hist = {'iteration': [], 'archive_size': [], 'front_size': [],
                'best': [], 'mean': [], 'snapshots': []}

        for it in range(1, cfg.max_iterations + 1):
            child_X = np.empty((self.n_pop, self.dim))
            child_F = np.empty((self.n_pop, self.n_obj))

            for i in range(self.n_pop):
                picks, pool = mating_indices(i, self.B, self.n_pop,
                                             cfg.delta, rng, k=2)
                p1 = X[picks[0]]
                p2 = X[picks[-1]] if len(picks) > 1 else X[i]
                y, _ = sbx(p1, p2, self.lower, self.upper,
                           cfg.crossover_prob, cfg.eta_c, rng)
                y = polynomial_mutation(y[None, :], self.lower, self.upper,
                                        self.p_mut, cfg.eta_m, rng)[0]
                fy = self._evaluate(y)
                child_X[i], child_F[i] = y, fy

                # update the reference points BEFORE the comparisons
                ref.update(fy)

                # --- replacement, capped at nr -----------------------------
                # Both scalarized values are computed for the whole pool in one
                # vectorised call, then the pool is walked in random order.
                order = replacement_order(pool, rng)
                W_pool = self.W[order]
                g_child = self._g(fy, W_pool, ref)   # (M,) broadcasts over (k, M)
                g_current = self._g(F[order], W_pool, ref)
                winners = order[g_child <= g_current][:cfg.nr]
                if len(winners):
                    X[winners] = y
                    F[winners] = fy

            archive.add(child_X, child_F)

            if (it % cfg.history_every == 0) or it == cfg.max_iterations:
                A_F, A_X = archive.front()
                Ff = pareto_front(A_F, objective_types=self.types) \
                    if len(A_F) else A_F
                hist['iteration'].append(it)
                hist['archive_size'].append(len(A_F))
                hist['front_size'].append(len(Ff))
                hist['best'].append(self._best_per_objective(F))
                hist['mean'].append(F.mean(axis=0))
                hist['snapshots'].append(Ff.copy())

        archive.finalise()
        runtime = time.perf_counter() - t0
        A_F, A_X = archive.front()
        if len(A_F):
            F_front, X_front = pareto_front(A_F, A_X, self.types)
        else:
            F_front, X_front = A_F, A_X

        return {
            'seed': self.seed,
            'population_decisions': X,
            'population_fitness': F,
            'archive_decisions': A_X,
            'archive_fitness': A_F,
            'front': F_front,
            'front_decisions': X_front,
            'ideal_point': ref.ideal.copy(),
            'nadir_estimate': ref.nadir.copy(),
            'weight_info': self.weight_info,
            'n_pop': self.n_pop,
            'runtime': runtime,
            'n_eval': self.n_eval,
            'history': hist,
        }


def run_single(problem, config, seed):
    """Convenience wrapper used by run_experiment.py."""
    return MOEAD(problem, config, seed=seed).run()
