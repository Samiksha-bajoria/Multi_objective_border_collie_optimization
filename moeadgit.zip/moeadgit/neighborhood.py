"""
neighborhood.py — the T closest weight vectors of every subproblem.

MOEA/D's central assumption is that neighbouring subproblems (weight vectors
that are close in Euclidean distance) have similar optima.

"""

import numpy as np


def compute_neighborhoods(W, T):
    """B[i] = indices of the T nearest weight vectors to W[i] (i included)."""
    W = np.asarray(W, dtype=float)
    n = len(W)
    T = int(min(max(T, 2), n))
    diff = W[:, None, :] - W[None, :, :]
    dist = np.sqrt(np.einsum('ijk,ijk->ij', diff, diff))
    return np.argsort(dist, axis=1, kind='stable')[:, :T]


def neighborhood_stats(B):
    """Small diagnostic used by check.py and the Parameters sheet."""
    B = np.asarray(B)
    return {'n_subproblems': int(B.shape[0]), 'T': int(B.shape[1]),
            'self_included': bool(np.all(B[:, 0] == np.arange(B.shape[0])))}
