# MOEA/D — Multi-Objective Optimisation Suite (native min **and** max objectives)

MOEA/D (Multi-Objective Evolutionary Algorithm based on Decomposition, Zhang &
Li 2007, with the Li & Zhang 2009 refinements) run over 27 benchmark
problems, with mixed minimisation/maximisation objective sets handled
natively — no maximisation objective is ever rewritten as `-f(x)`.


---

## Folder structure

```
MOEAD/
├── figures/                     # all PNG output (created/filled at run time)
├── results/                     # all .xlsx output (created/filled at run time)
├── venv/                        # your virtual environment (not in this bundle)
│
├── archive.py                   # external non-dominated archive
├── check.py                     # self-test: run this first
├── config.py                    # every parameter of the study
├── crossover.py                 # SBX crossover
├── dataset.py                   # the 27-problem registry (dims, bounds, directions)
├── decomposition.py             # Tchebycheff / Weighted-Sum / PBI scalarizers
├── dominance.py                 # mixed min/max Pareto dominance
├── evopinn_problem.py           # the 12 EvoPINN problems (your file, unchanged)
├── excel_writer.py              # workbook generation
├── fitness.py                   # ideal/nadir points + subproblem fitness
├── generate.py                  # true (expected) Pareto fronts
├── main.py                      # entry point
├── metrics.py                   # HV, IGD, GD, Spacing, Spread, Epsilon
├── mixed_test_functions.py      # Mixed_ZDT1, Mixed_DTLZ1, Mixed_DTLZ2
├── mutation.py                  # polynomial mutation
├── neighborhood.py              # the T nearest weight vectors of each subproblem
├── nondominated_sort.py         # fast non-dominated sorting
├── optimizer.py                 # the MOEA/D loop
├── README.md
├── requirements.txt
├── run_experiment.py            # 40 runs of one problem + metric aggregation
├── selection.py                 # neighbourhood-vs-population mating selection
├── standard_test_functions.py   # ZDT1-4, ZDT6, DTLZ1-7
├── visualization.py             # expected-vs-reality figures
└── weight_vectors.py            # Das-Dennis uniform weight vectors
```


---

## Quick start

```bash
cd MOEAD
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt

python check.py                   # verify the install + the mixed min/max logic
python main.py                    # the full study (27 problems)
```

Useful flags:

```bash
python main.py --quick                                  # 3 runs x 10 iters, seconds
python main.py --problems ZDT1 Mixed_DTLZ2              # a subset
python main.py --runs 40 --iterations 100               # the stated minimum
python main.py --iterations 1000 --problems DTLZ3 ZDT4  # the hard multi-modal ones
python main.py --no-figures
```
---

## How MOEA/D works here

```
generate N uniformly spread weight vectors  ->  N scalar subproblems
B(i) ← the T nearest weight vectors of λ^i
P    ← random population, one solution per subproblem
z*   ← direction-aware ideal point of P
repeat
    for every subproblem i:
        pool  ← B(i) with probability δ, else the whole population
        child ← polynomial_mutation( SBX( two parents from pool ) )
        evaluate child; update z* and the nadir estimate
        for at most nr members j of pool, in random order:
            if g(child | λ^j, z*) ≤ g(x_j | λ^j, z*):  x_j ← child
    push this generation's children into the external archive
until max_iterations
```

### Weight vectors

| Objectives | Method | Count |
|---|---|---|
| M = 2 | uniform 2-D | 100 (= `n_population`) |
| M = 3 | Das-Dennis lattice, H=13 | 105 |
| M = 4 (EvoPINN) | H=6 | 84 |

Everything else — the external archive, front extraction, the epsilon
indicator, the HV reference point, the Excel best/worst columns, the figure
axis labels — routes through `dominance.py`, which applies `a_j ≤ b_j` for min
and `a_j ≥ b_j` for max.

Switch scalarizer in `config.py` or compare all three:

```python
MOEADConfig(decomposition='pbi', pbi_theta=5.0)
```

---

## The 27 problems

| Family | Problems | Objectives | Directions |
|---|---|---|---|
| EvoPINN | `EvoPINN1_Poisson1D` … `EvoPINN12_Schrodinger1D` | 4 | all min |
| ZDT | ZDT1, ZDT2, ZDT3, ZDT4, ZDT6 | 2 | all min |
| DTLZ | DTLZ1 … DTLZ7 | 3 | all min |
| Mixed | Mixed_ZDT1, Mixed_DTLZ1, Mixed_DTLZ2 | 2 / 3 / 3 | **min + max** |

Each problem carries its **own** dimension and its **own per-variable bounds**
(ZDT4 uses `x1 ∈ [0,1]` with `x2..x10 ∈ [-5,5]`; the EvoPINN dimensions are
derived from the underlying network — 141 to 218 weights).

### The three mixed problems (with closed-form fronts)

| Problem | Objectives | True Pareto front |
|---|---|---|
| **Mixed_ZDT1** (dim 30) | min `f1 = x1` (cost); max `f2 = √x1 / g` (yield) | `f2 = √f1`, `f1 ∈ [0,1]` |
| **Mixed_DTLZ1** (dim 7) | min `f1, f2`; max `f3 = 0.5·x1/(1+g)` (throughput) | triangle `f3 = f1 + f2`, `f1+f2 ≤ 0.5` |
| **Mixed_DTLZ2** (dim 12) | min `f1, f2`; max `f3 = cos(πx1/2)/(1+g)` (signal) | cone `f3 = √(f1²+f2²)`, `f3 ∈ [0,1]` |


---
