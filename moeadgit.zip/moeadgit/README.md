# MOEA/D — Multi-Objective Optimisation Suite (native min **and** max objectives)

MOEA/D (Multi-Objective Evolutionary Algorithm based on Decomposition, Zhang &
Li 2007, with the Li & Zhang 2009 refinements) run over **27 benchmark
problems**, with mixed minimisation/maximisation objective sets handled
*natively* — no maximisation objective is ever rewritten as `-f(x)`.

Companion project to the SPEA2 suite: identical problem set, identical Excel
layout and identical metrics, so the two algorithms are directly comparable
workbook-for-workbook.

---

## Folder structure

```
MOEAD/
├── figures/                     # all PNG output (created/filled at run time)
├── results/                     # all .xlsx output (created/filled at run time)
├── venv/                        # your virtual environment (not in this bundle)
│
├── archive.py                   # external non-dominated archive
├── check.py                     # self-test: run this first
├── config.py                    # every parameter of the study
├── crossover.py                 # SBX crossover
├── dataset.py                   # the 27-problem registry (dims, bounds, directions)
├── decomposition.py             # Tchebycheff / Weighted-Sum / PBI scalarizers
├── dominance.py                 # mixed min/max Pareto dominance
├── evopinn_problem.py           # the 12 EvoPINN problems (your file, unchanged)
├── excel_writer.py              # workbook generation
├── fitness.py                   # ideal/nadir points + subproblem fitness
├── generate.py                  # true (expected) Pareto fronts
├── main.py                      # entry point
├── metrics.py                   # HV, IGD, GD, Spacing, Spread, Epsilon
├── mixed_test_functions.py      # Mixed_ZDT1, Mixed_DTLZ1, Mixed_DTLZ2
├── mutation.py                  # polynomial mutation
├── neighborhood.py              # the T nearest weight vectors of each subproblem
├── nondominated_sort.py         # fast non-dominated sorting
├── optimizer.py                 # the MOEA/D loop
├── README.md
├── requirements.txt
├── run_experiment.py            # 40 runs of one problem + metric aggregation
├── selection.py                 # neighbourhood-vs-population mating selection
├── standard_test_functions.py   # ZDT1-4, ZDT6, DTLZ1-7
├── visualization.py             # expected-vs-reality figures
└── weight_vectors.py            # Das-Dennis uniform weight vectors
```

Same layout as the MOBCO / SPEA2 projects. The files that encode *algorithm*
mechanics differ because the algorithms differ: MOEA/D has no crowding distance
or strength fitness, so those slots hold `weight_vectors.py`,
`neighborhood.py`, `decomposition.py` and `fitness.py`. Everything downstream
of the optimiser — `dataset`, `metrics`, `excel_writer`, `visualization`,
`generate`, `dominance` — is byte-identical to the SPEA2 project, which is what
makes the two sets of results comparable.

---

## Quick start

```bash
cd MOEAD
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt

python check.py                   # verify the install + the mixed min/max logic
python main.py                    # the full study (27 problems)
```

Useful flags:

```bash
python main.py --quick                                  # 3 runs x 10 iters, seconds
python main.py --problems ZDT1 Mixed_DTLZ2              # a subset
python main.py --runs 40 --iterations 100               # the stated minimum
python main.py --iterations 1000 --problems DTLZ3 ZDT4  # the hard multi-modal ones
python main.py --no-figures
```

**Defaults:** Tchebycheff decomposition, ~100 subproblems, T=20, delta=0.9,
nr=2, **100 iterations**, **40 independent runs**, SBX (p=0.9, eta=20) +
polynomial mutation (p=1/dim, eta=20).

Budget roughly 1–1.5 h wall-clock for the whole 27-problem sweep on one core.
MOEA/D is slower per generation than SPEA2 because it does one crossover, one
mutation and one function evaluation *per subproblem per generation* rather
than one vectorised batch — that is inherent to the algorithm, not an
inefficiency in this implementation.

> **Expect DTLZ1, DTLZ3 and ZDT4 to score badly at 100 iterations.** All three
> are strongly multi-modal and are still far from their true fronts at
> generation 100 — DTLZ1 and DTLZ3 typically report hypervolume 0.0 with a large
> IGD. That is a genuine non-convergence result rather than a bug: the g-function
> of those problems has thousands of local fronts and the population is still
> descending it. `--iterations 300` converges DTLZ1 (HV ≈ 0.82) and ZDT4;
> DTLZ3 needs closer to 1000. Everything else in the suite converges fine at 100.

---

## How MOEA/D works here

```
generate N uniformly spread weight vectors  ->  N scalar subproblems
B(i) ← the T nearest weight vectors of λ^i
P    ← random population, one solution per subproblem
z*   ← direction-aware ideal point of P
repeat
    for every subproblem i:
        pool  ← B(i) with probability δ, else the whole population
        child ← polynomial_mutation( SBX( two parents from pool ) )
        evaluate child; update z* and the nadir estimate
        for at most nr members j of pool, in random order:
            if g(child | λ^j, z*) ≤ g(x_j | λ^j, z*):  x_j ← child
    push this generation's children into the external archive
until max_iterations
```

### Weight vectors

| Objectives | Method | Count |
|---|---|---|
| M = 2 | uniform 2-D | 100 (= `n_population`) |
| M = 3 | Das-Dennis lattice, H=13 | 105 |
| M = 4 (EvoPINN) | Das-Dennis lattice, H=6 | 84 |

The Das-Dennis count is `C(H+M-1, M-1)`, which cannot hit an arbitrary target
exactly — so `n_population` is a *target* and the real population size is
whichever lattice sits closest. Both numbers are recorded in the `Parameters`
sheet so nothing is ambiguous.

### How mixed directions are handled

The ideal point `z*` is tracked per objective in **that objective's own
direction** — the minimum seen so far for a `'min'` objective, the maximum seen
so far for a `'max'` one. Every scalarizer then acts on the non-negative
deviation `d_j = |f_j − z*_j| / range_j`, which shrinks as objective *j* gets
better whatever its direction. So `g` is always minimised and no objective is
ever multiplied by −1.

`check.py` step 7 asserts exactly this: for all three scalarizers, raising a
maximised objective must *lower* `g`.

Everything else — the external archive, front extraction, the epsilon
indicator, the HV reference point, the Excel best/worst columns, the figure
axis labels — routes through `dominance.py`, which applies `a_j ≤ b_j` for min
and `a_j ≥ b_j` for max.

### Scalarizer normalisation

`normalize_scalarizer` (on by default) divides each deviation by the observed
`|nadir − ideal|` range. This matters a great deal for the EvoPINN problems,
whose four losses routinely span several orders of magnitude — without it the
residual loss alone would decide every Tchebycheff comparison and the other
three objectives would be effectively ignored. It rescales distances only; it
changes no direction and no stored value.

Switch scalarizer in `config.py` or compare all three:

```python
MOEADConfig(decomposition='pbi', pbi_theta=5.0)
```

---

## The 27 problems

| Family | Problems | Objectives | Directions |
|---|---|---|---|
| EvoPINN | `EvoPINN1_Poisson1D` … `EvoPINN12_Schrodinger1D` | 4 | all min |
| ZDT | ZDT1, ZDT2, ZDT3, ZDT4, ZDT6 | 2 | all min |
| DTLZ | DTLZ1 … DTLZ7 | 3 | all min |
| Mixed | Mixed_ZDT1, Mixed_DTLZ1, Mixed_DTLZ2 | 2 / 3 / 3 | **min + max** |

Each problem carries its **own** dimension and its **own per-variable bounds**
(ZDT4 uses `x1 ∈ [0,1]` with `x2..x10 ∈ [-5,5]`; the EvoPINN dimensions are
derived from the underlying network — 141 to 218 weights).

### The three mixed problems (with closed-form fronts)

| Problem | Objectives | True Pareto front |
|---|---|---|
| **Mixed_ZDT1** (dim 30) | min `f1 = x1` (cost); max `f2 = √x1 / g` (yield) | `f2 = √f1`, `f1 ∈ [0,1]` |
| **Mixed_DTLZ1** (dim 7) | min `f1, f2`; max `f3 = 0.5·x1/(1+g)` (throughput) | triangle `f3 = f1 + f2`, `f1+f2 ≤ 0.5` |
| **Mixed_DTLZ2** (dim 12) | min `f1, f2`; max `f3 = cos(πx1/2)/(1+g)` (signal) | cone `f3 = √(f1²+f2²)`, `f3 ∈ [0,1]` |

Each maximised component is a quantity that is genuinely meaningful to make
large, and it is constructed to **oppose** the minimised ones — the minimised
objectives pull `x1 → 0` while the maximised one pulls `x1 → 1`, so the
conflict is real rather than cosmetic. A plain sign flip of an existing
ZDT/DTLZ objective would have produced an aligned (degenerate) objective set
with a single ideal point.

---

## Excel output

`results/MOEAD_<Problem>.xlsx`, one workbook per problem. **Sheet 1 is exactly
the requested layout:**

| Run | Hypervolume | IGD | GD | Spacing | Spread | Epsilon | Runtime |
|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | 0.8452 | 0.0123 | 0.0089 | 0.043 | 0.376 | 0.021 | 1.42 |
| … | … | … | … | … | … | … | … |
| 40 | … | … | … | … | … | … | … |

Remaining sheets:

| Sheet | Contents |
|---|---|
| `Statistics` | mean / std / median / best / worst per indicator across the 40 runs |
| `Parameters` | full MOEA/D configuration: decomposition, weights, T, δ, nr, ideal & nadir points |
| `Objective_Info` | index, name, **Minimize/Maximize**, best & worst observed |
| `Iteration_History` | per-generation HV / IGD / GD / sizes and per-objective best & mean, averaged over runs |
| `Pareto_Solutions` | decision variables + objectives of the best run's front |
| `Archive` | the best run's full external archive |
| `Reference_Front` | the *expected* front (analytic, or approximated for EvoPINN) |
| `Expected_vs_Reality` | per-objective expected vs obtained best/worst and the gap |
| `Weight_Vectors` | every subproblem's λ and the best run's final value at it |

`results/MOEAD_Master_Summary.xlsx` adds a cross-problem sheet, an all-runs dump
and the configuration.

### About the indicators

* **Hypervolume** — normalised to `[0,1]` (fraction of the reference box that is
  dominated), so values are comparable across problems and across the two
  algorithms. Exact for 2 objectives, Monte-Carlo for 3+. Directions enter
  through the reference point: the axis-wise distance is `ref_j − f_j` for a
  minimised objective and `f_j − ref_j` for a maximised one. **HV = 0 means the
  run never reached the reference box** — a genuine non-convergence signal, not
  a bug.
* **GD / IGD / Spacing / Spread** — pure geometric distances, computed after
  min-max *scaling* each objective into the reference-front box.
* **Epsilon** — additive `I_ε+(A,R)`, direction-aware.
* All 40 runs of a problem share **one** reference front and **one** reference
  point, fixed before the runs are scored.

Reference fronts: analytic for ZDT/DTLZ/Mixed; for the twelve EvoPINN problems
no analytic front exists, so the reference set is the non-dominated union of
every run's archive, reported as such in `Parameters` and `Reference_Front`.

---

## Figures

`figures/<Problem>_front.png` — **expected vs reality**: 2-D scatter, 3-D
scatter plus projection, or (for the 4-objective EvoPINN problems) parallel
coordinates plus a log-log projection. Grey = expected reference front,
red = the best run, blue = all runs combined. Axis labels state the direction,
e.g. `f2 · Yield (MAXIMISE)`.

`figures/<Problem>_convergence.png` — mean HV / IGD / GD and archive size per
iteration.
`figures/<Problem>_distribution.png` — box plots of the six indicators over the
40 runs.
`figures/<Problem>_decomposition.png` — **MOEA/D-specific**: the weight vectors,
and a histogram of how evenly the final population covers them.
`figures/00_overview_hypervolume.png` — mean HV across all 27 problems.

---

## Comparing against SPEA2

Both projects write the same sheet names, the same eight `Run_Summary` columns
and the same normalised hypervolume against the same reference fronts. To
compare, run both and read the two `Master_Summary` sheets side by side, or the
two `All_Runs` sheets if you want a per-run statistical test (a Wilcoxon
rank-sum over the 40 paired runs is the usual choice).

One caveat worth stating plainly: identical *metric* definitions make the
numbers comparable, but the two algorithms do not spend the same number of
function evaluations per generation. MOEA/D evaluates N children per
generation, SPEA2 also evaluates N — so at equal iterations the budgets do
match here. Runtime differs anyway because MOEA/D's per-subproblem loop is not
vectorised, which is a property of the algorithm rather than of the budget.
