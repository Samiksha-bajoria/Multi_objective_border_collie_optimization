"""
check.py — run this first.  It verifies the installation and, more importantly,
that the mixed minimise/maximise machinery actually behaves the way it claims.

    python check.py

Checks performed
  1. every one of the 27 problems builds, and dim / bounds / directions agree
  2. every problem evaluates a random point to a finite objective vector
  3. dominance respects 'max' columns (a larger value is BETTER there)
  4. no maximisation objective was silently converted to minimisation
  5. the analytic reference fronts are internally non-dominated
  6. a short MOEA/D run improves hypervolume from the first to the last iteration
"""

import numpy as np

from config import MOEADConfig
from dataset import PROBLEM_NAMES, get_problem, bounds_arrays, problem_table
from dominance import dominates, nondominated_mask
from metrics import MetricContext, evaluate_front
from optimizer import run_single

OK, FAIL = '  [ok]  ', '  [FAIL]'


def check_problems():
    print('1-2. building and evaluating all problems')
    rng = np.random.default_rng(0)
    bad = 0
    for row in problem_table():
        p = get_problem(row['Problem'])
        lo, hi = bounds_arrays(p)
        x = lo + rng.random(p['dim']) * (hi - lo)
        f = p['evaluate'](x)
        ok = (len(lo) == p['dim'] and len(f) == p['n_obj']
              and np.all(np.isfinite(f))
              and len(p['objective_types']) == p['n_obj'])
        bad += (not ok)
        print(f"{OK if ok else FAIL} {p['name']:<28} dim={p['dim']:<4} "
              f"M={p['n_obj']}  dirs={','.join(p['objective_types']):<15} "
              f"f={np.array2string(f, precision=3, max_line_width=200)}")
    return bad


def check_dominance():
    print('\n3. dominance with a mixed direction set  (min, max)')
    types = ['min', 'max']
    a = np.array([1.0, 5.0])      # lower f1 AND higher f2 -> better on both
    b = np.array([2.0, 3.0])
    t1 = dominates(a, b, types) and not dominates(b, a, types)
    print(f"{OK if t1 else FAIL} [1,5] dominates [2,3] under (min,max)")

    c = np.array([1.0, 2.0])      # better f1, worse f2 -> mutually non-dominated
    d = np.array([2.0, 4.0])
    t2 = (not dominates(c, d, types)) and (not dominates(d, c, types))
    print(f"{OK if t2 else FAIL} [1,2] and [2,4] are mutually non-dominated")

    F = np.array([[1.0, 5.0], [2.0, 3.0], [0.5, 1.0], [3.0, 9.0]])
    mask = nondominated_mask(F, types)
    t3 = bool(mask[0] and mask[2] and mask[3] and not mask[1])
    print(f"{OK if t3 else FAIL} non-dominated mask = {mask.astype(int)}")
    return int(not (t1 and t2 and t3))


def check_no_conversion():
    print('\n4. maximisation objectives are stored unconverted')
    bad = 0
    for name in ('Mixed_ZDT1', 'Mixed_DTLZ1', 'Mixed_DTLZ2'):
        p = get_problem(name)
        lo, hi = bounds_arrays(p)
        rng = np.random.default_rng(7)
        F = np.array([p['evaluate'](lo + rng.random(p['dim']) * (hi - lo))
                      for _ in range(200)])
        for j, t in enumerate(p['objective_types']):
            if t != 'max':
                continue
            positive = bool(np.all(F[:, j] >= -1e-12))
            bad += (not positive)
            print(f"{OK if positive else FAIL} {name} f{j+1} is a genuine "
                  f"'max' quantity, range "
                  f"[{F[:, j].min():.4f}, {F[:, j].max():.4f}] (no sign flip)")
    return bad


def check_reference_fronts():
    print('\n5. analytic reference fronts are internally non-dominated')
    bad = 0
    for name in PROBLEM_NAMES:
        p = get_problem(name)
        if p['true_front'] is None:
            continue
        R = p['true_front'](300)
        frac = nondominated_mask(R, p['objective_types']).mean()
        ok = frac > 0.98
        bad += (not ok)
        print(f"{OK if ok else FAIL} {p['name']:<14} "
              f"{frac * 100:5.1f}% of {len(R)} reference points non-dominated")
    return bad


def check_optimizer():
    print('\n6. short MOEA/D run improves the hypervolume')
    cfg = MOEADConfig(n_population=40, archive_size=40, max_iterations=25,
                      n_runs=1, history_metric_runs=1, T=8,
                      hv_mc_samples_history=2000)
    bad = 0
    for name in ('ZDT1', 'Mixed_ZDT1', 'DTLZ2', 'Mixed_DTLZ2'):
        p = get_problem(name)
        out = run_single(p, cfg, seed=1)
        ctx = MetricContext(p['true_front'](400), p['objective_types'])
        first = evaluate_front(out['history']['snapshots'][0], ctx, 4000)['hv']
        last = evaluate_front(out['front'], ctx, 8000)['hv']
        ok = last >= first
        bad += (not ok)
        print(f"{OK if ok else FAIL} {name:<12} HV {first:.4f} -> {last:.4f} "
              f"({len(out['front'])} front points, {out['runtime']:.2f}s)")
    return bad


def check_weights_and_decomposition():
    print('\n7. weight vectors, neighbourhoods and the three scalarizers')
    from decomposition import METHODS, scalarize
    from fitness import ReferencePoint
    from neighborhood import compute_neighborhoods, neighborhood_stats
    from weight_vectors import generate_weights

    bad = 0
    for m in (2, 3, 4):
        W, info = generate_weights(100, m)
        ok = (abs(W.sum(axis=1) - 1).max() < 1e-9) and np.all(W > 0)
        bad += (not ok)
        print(f"{OK if ok else FAIL} M={m}: {info['n_weights']:>4} weights "
              f"({info['method']}"
              + (f", H={info['H']}" if info['H'] else '') + "), rows sum to 1")
        B = compute_neighborhoods(W, 20)
        st = neighborhood_stats(B)
        ok2 = st['self_included'] and st['T'] == 20
        bad += (not ok2)
        print(f"{OK if ok2 else FAIL} M={m}: neighbourhoods T={st['T']}, "
              f"every subproblem is its own nearest weight")

    # a maximised objective must make the scalarized value SMALLER as it grows
    types = ['min', 'max']
    ref = ReferencePoint(types).update(np.array([[0.0, 1.0], [1.0, 0.0]]))
    w = np.array([0.5, 0.5])
    scale = ref.scale(True)
    for method in METHODS:
        worse = scalarize(np.array([0.5, 0.2]), w, ref.ideal, method, scale)
        better = scalarize(np.array([0.5, 0.8]), w, ref.ideal, method, scale)
        ok = better < worse
        bad += (not ok)
        print(f"{OK if ok else FAIL} {method:<13} higher f2 (maximised) lowers g: "
              f"{worse:.4f} -> {better:.4f}")
    return bad


def main():
    print('MOEA/D project self-check\n' + '=' * 70)
    bad = 0
    bad += check_problems()
    bad += check_dominance()
    bad += check_no_conversion()
    bad += check_reference_fronts()
    bad += check_optimizer()
    bad += check_weights_and_decomposition()
    print('\n' + '=' * 70)
    print('ALL CHECKS PASSED' if bad == 0 else f'{bad} CHECK(S) FAILED')
    return 0 if bad == 0 else 1


if __name__ == '__main__':
    raise SystemExit(main())
