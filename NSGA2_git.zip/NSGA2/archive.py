"""
archive.py — the elite population P_t of NSGA-II.

NSGA-II keeps no separate external archive the way SPEA2 does: the current
population *is* the elite set, refreshed every generation by merging P_t
with the offspring Q_t and keeping the best `size` solutions under rank +
crowding distance. This class keeps the same name, file and role it has in
the SPEA2-shaped project (optimizer.py talks to it the same way) — inside,
it now wraps fitness.nsga2_fitness + environmental_selection instead of
SPEA2's strength/density fitness assignment and nearest-neighbour
truncation.
"""

import numpy as np

from fitness import nsga2_fitness
from environmental_selection import environmental_selection
from nondominated_sort import pareto_front


class Archive:
    def __init__(self, size, objective_types):
        self.size = size
        self.objective_types = objective_types
        self.X = np.zeros((0, 0))
        self.F = np.zeros((0, len(objective_types)))
        self.rank = np.zeros(0, dtype=int)
        self.fitness = np.zeros(0)      # crowding distance (used by selection.py)

    def __len__(self):
        return len(self.F)

    def update(self, X_pop, F_pop):
        """One generational-replacement step: P_{t+1} <- best of P_t U Q_t."""
        if len(self.X) == 0:
            X_union, F_union = np.asarray(X_pop, float), np.asarray(F_pop, float)
        else:
            X_union = np.vstack([X_pop, self.X])
            F_union = np.vstack([F_pop, self.F])

        info = nsga2_fitness(F_union, self.objective_types)
        Xa, Fa, sel = environmental_selection(X_union, F_union, info, self.size)
        self.X, self.F = Xa, Fa
        self.rank = info['rank'][sel]
        self.fitness = info['crowding'][sel]
        return info

    def front(self):
        """Non-dominated subset of the population (objectives, decisions)."""
        if len(self.F) == 0:
            return self.F.copy(), self.X.copy()
        return pareto_front(self.F, self.X, self.objective_types)
