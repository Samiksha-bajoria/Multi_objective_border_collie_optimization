"""
fitness.py — NSGA-II rank + crowding-distance assignment
(Deb, Pratap, Agarwal & Meyarivan, 2002).

For the union  U = P_t U Q_t  (parents + offspring):

    rank(i)      = index of the non-dominated front i belongs to
                   (0 = the non-dominated front F1, 1 = F2, ...)
    crowding(i)  = crowding distance of i inside its own front

Together these implement NSGA-II's crowded-comparison operator: i is
preferred over j when

    rank(i) < rank(j)                                  or
    rank(i) == rank(j)  and  crowding(i) > crowding(j)

All dominance tests go through dominance.py (via nondominated_sort.py), so
mixed minimise/maximise objective sets are handled natively — nothing is
converted.
"""

import numpy as np

from nondominated_sort import fast_nondominated_sort
from density_estimation import crowding_distance


def nsga2_fitness(F_obj, objective_types):
    """
    Returns a dict with the front list, the rank of every solution and its
    crowding distance within that front — everything environmental_selection
    and selection.py need.
    """
    F_obj = np.asarray(F_obj, dtype=float)
    n = len(F_obj)
    if n == 0:
        empty = np.zeros(0)
        return {'fronts': [], 'rank': empty.astype(int), 'crowding': empty}

    fronts = fast_nondominated_sort(F_obj, objective_types)
    rank = np.zeros(n, dtype=int)
    crowding = np.zeros(n, dtype=float)
    for r, front in enumerate(fronts):
        rank[front] = r
        crowding[front] = crowding_distance(F_obj[front])

    return {'fronts': fronts, 'rank': rank, 'crowding': crowding}


def nondominated_indices_from_rank(rank):
    """NSGA-II shortcut: rank == 0 means non-dominated in the union."""
    return np.flatnonzero(np.asarray(rank) == 0)
