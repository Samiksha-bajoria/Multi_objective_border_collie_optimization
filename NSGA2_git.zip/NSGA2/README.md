# NSGA-II — Multi-Objective Optimisation Suite (native min **and** max objectives)

NSGA-II (Non-dominated Sorting Genetic Algorithm II) run over **27 benchmark
problems**, with mixed minimisation/maximisation objective sets handled
*natively* — no maximisation objective is ever rewritten as `-f(x)`.

---

## Folder structure

```
NSGA2/
├── figures/                     # all PNG output (created/filled at run time)
├── results/                     # all .xlsx output (created/filled at run time)
├── venv/                        # your virtual environment (not in this bundle)
│
├── archive.py                   # the elite population P_t
├── check.py                     # self-test: run this first
├── config.py                    # every parameter of the study
├── crossover.py                 # SBX crossover
├── dataset.py                   # the 27-problem registry (dims, bounds, directions)
├── density_estimation.py        # crowding distance (NSGA-II's D(i))
├── dominance.py                 # mixed min/max Pareto dominance
├── environmental_selection.py   # front-by-front fill + crowding-distance truncation
├── evopinn_problem.py           # the 12 EvoPINN problems (your file, unchanged)
├── excel_writer.py              # workbook generation
├── fitness.py                   # NSGA-II rank + crowding-distance assignment
├── generate.py                  # true (expected) Pareto fronts
├── main.py                      # entry point
├── metrics.py                   # HV, IGD, GD, Spacing, Spread, Epsilon
├── mixed_test_functions.py      # Mixed_ZDT1, Mixed_DTLZ1, Mixed_DTLZ2
├── mutation.py                  # polynomial mutation
├── nondominated_sort.py         # fast non-dominated sorting
├── optimizer.py                 # the NSGA-II loop
├── README.md
├── requirements.txt
├── run_experiment.py            # 50 runs of one problem + metric aggregation
├── selection.py                 # crowded binary tournament mating selection
├── standard_test_functions.py   # ZDT1-4, ZDT6, DTLZ1-7
└── visualization.py             # expected-vs-reality figures
```

The layout mirrors the SPEA2 project one-to-one. The five files that encode
*that* algorithm's mechanics — `fitness.py` (strength/raw/total fitness),
`density_estimation.py` (k-th nearest-neighbour density), `environmental_selection.py`
(archive fill + nearest-neighbour truncation), `selection.py` (tournament on
scalar fitness) and `archive.py` (the external archive A_t) — have been
rewritten with NSGA-II's own mechanics in the same slots: rank + crowding
distance, front-by-front elitist replacement, crowded binary tournament, and
an elite population that plays the archive's structural role. Everything
else — problem definitions, metrics, dominance rules, variation operators,
Excel/figure generation — keeps the exact same filename and responsibility.

---

## Quick start

```bash
cd NSGA2
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt

python check.py                   # verify the install + the mixed min/max logic
python main.py                    # the full study (all 27 problems)
```

Useful flags:

```bash
python main.py --quick                                  # 3 runs x 10 iters, seconds
python main.py --problems ZDT1 Mixed_DTLZ2               # a subset
python main.py --runs 40 --iterations 100                # the stated minimum
python main.py --iterations 1000 --problems DTLZ3 ZDT4    # the hard multi-modal ones
python main.py --no-figures
```

You will see step-by-step progress in the terminal as it runs: which problem
is being solved, each run's front/population size and runtime, the reference
front used, the aggregated HV/IGD/GD once all runs of a problem finish, and
the path of every workbook and figure as it is written.

**Defaults:** population 100, elite population 100, **200 iterations**, **50
independent runs**, SBX (p=0.9, eta=20) + polynomial mutation (p=1/dim,
eta=20). Expect a lot less wall-clock time than a comparably-configured
SPEA2 run for the same problem, since NSGA-II's crowding distance is O(n log n)
per front instead of an O(n^2) k-NN density pass — the twelve EvoPINN
problems still dominate the total budget.

---

## The 27 problems

| Family | Problems | Objectives | Directions |
|---|---|---|---|
| EvoPINN | `EvoPINN1_Poisson1D` … `EvoPINN12_Schrodinger1D` | 4 | all min |
| ZDT | ZDT1, ZDT2, ZDT3, ZDT4, ZDT6 | 2 | all min |
| DTLZ | DTLZ1 … DTLZ7 | 3 | all min |
| Mixed | Mixed_ZDT1, Mixed_DTLZ1, Mixed_DTLZ2 | 2 / 3 / 3 | **min + max** |

Each problem carries its **own** dimension and its **own per-variable bounds**
(ZDT4, for instance, uses `x1 ∈ [0,1]` with `x2..x10 ∈ [-5,5]`; the EvoPINN
dimensions are derived from the underlying network — 141 to 218 weights).
`config.py`'s `problems` list is empty by default, so `main.py` runs **all
27** unless you pass `--problems`.

### How mixed directions are handled

`dominance.py` never transforms an objective value. For objective *j*:

* `'min'`: *a* is at least as good as *b* ⟺ `a_j <= b_j`
* `'max'`: *a* is at least as good as *b* ⟺ `a_j >= b_j`

That single rule propagates everywhere — NSGA-II's fast non-dominated
sorting, the crowded-comparison operator, front extraction, the epsilon
indicator, the hypervolume reference point, the Excel "best/worst" columns
and the figure axis labels. What the test function returns is what gets
stored, plotted and reported.

### The three mixed problems (with closed-form fronts)

| Problem | Objectives | True Pareto front |
|---|---|---|
| **Mixed_ZDT1** (dim 30) | min `f1 = x1` (cost); max `f2 = √x1 / g` (yield) | `f2 = √f1`, `f1 ∈ [0,1]` |
| **Mixed_DTLZ1** (dim 7) | min `f1, f2`; max `f3 = 0.5·x1/(1+g)` (throughput) | triangle `f3 = f1 + f2`, `f1+f2 ≤ 0.5` |
| **Mixed_DTLZ2** (dim 12) | min `f1, f2`; max `f3 = cos(πx1/2)/(1+g)` (signal) | cone `f3 = √(f1²+f2²)`, `f3 ∈ [0,1]` |

Each maximised component is a quantity that is genuinely meaningful to make
large, and it is constructed to **oppose** the minimised ones. `check.py`
step 4 asserts that no maximised column was sign-flipped.

---

## Excel output

`results/NSGA2_<Problem>.xlsx`, one workbook per problem. **Sheet 1 is
exactly the requested layout:**

| Run | Hypervolume | IGD | GD | Spacing | Spread | Epsilon | Runtime |
|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | 0.8452 | 0.0123 | 0.0089 | 0.043 | 0.376 | 0.021 | 1.42 |
| … | … | … | … | … | … | … | … |
| 50 | … | … | … | … | … | … | … |

Remaining sheets:

| Sheet | Contents |
|---|---|
| `Statistics` | mean / std / median / best / worst per indicator across all runs |
| `Parameters` | the exact NSGA-II configuration used, incl. the HV reference point |
| `Objective_Info` | index, name, **Minimize/Maximize**, best & worst observed |
| `Iteration_History` | per-generation HV / IGD / GD / sizes and per-objective best & mean, averaged over runs |
| `Pareto_Solutions` | decision variables + objectives of the best run's front |
| `Archive` | the best run's full elite population |
| `Reference_Front` | the *expected* front (analytic, or approximated for EvoPINN) |
| `Expected_vs_Reality` | per-objective expected vs obtained best/worst and the gap |

`results/NSGA2_Master_Summary.xlsx` adds a cross-problem sheet, an all-runs
dump and the configuration.

### About the indicators

* **Hypervolume** — normalised to `[0,1]` (fraction of the reference box that
  is dominated), so values are comparable across problems. Exact for 2
  objectives, Monte-Carlo for 3+. **HV = 0 means the run never reached the
  reference box** — a genuine non-convergence signal, not a bug.
* **GD / IGD / Spacing / Spread** — pure geometric distances, computed after
  min-max *scaling* each objective into the reference-front box.
* **Epsilon** — additive `I_ε+(A,R)`, direction-aware.
* All runs of a problem share **one** reference front and **one** reference
  point, fixed before the runs are scored.

Reference fronts: analytic for ZDT/DTLZ/Mixed; for the twelve EvoPINN problems
no analytic front exists, so the reference set is the non-dominated union of
every run's elite population (the standard fallback), reported as such in
`Parameters` and `Reference_Front`.

---

## Figures

`figures/<Problem>_front.png` — **expected vs reality**: 2-D scatter, 3-D
scatter plus projection, or (for the 4-objective EvoPINN problems) parallel
coordinates plus a log-log projection. Grey = expected reference front, red =
the best run, blue = all runs combined.

`figures/<Problem>_convergence.png` — mean HV / IGD / GD and population size
per iteration.
`figures/<Problem>_distribution.png` — box plots of the six indicators over
all runs.
`figures/00_overview_hypervolume.png` — mean HV across all 27 problems.

---

## Algorithm summary

```
P_0 ← random population (uniform in the problem's own bounds)
for t = 1 … max_iterations:
    mating pool ← crowded binary tournament on P_t
                  (lower rank wins; ties broken by higher crowding distance)
    Q_t ← polynomial_mutation( SBX( mating pool ) )
    R_t ← P_t ∪ Q_t
    F1, F2, ... ← fast_nondominated_sort(R_t)          # mixed-direction dominance
    P_{t+1} ← fill fronts F1, F2, ... while they fit;
              the first front that overflows is truncated by descending
              crowding distance (elitist replacement, |P_{t+1}| = N_pop)
```
