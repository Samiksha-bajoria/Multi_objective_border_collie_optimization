"""
config.py — every tunable knob of the NSGA-II experiment lives here.

Nothing in this project hard-codes a parameter: optimizer.py, run_experiment.py,
excel_writer.py and visualization.py all read from a single NSGA2Config object.
"""

from dataclasses import dataclass, field, asdict
from pathlib import Path


@dataclass
class NSGA2Config:
    # ---- NSGA-II core -----------------------------------------------------
    n_population: int = 300          # size of P_t (and of the offspring Q_t)
    archive_size: int = 300          # size of the elite population kept each
                                      # generation; NSGA-II's elitist
                                      # replacement sets this equal to
                                      # n_population
    max_iterations: int = 1000        # >= 100 as required
    n_runs: int = 50                 # >= 40 independent runs as required
    base_seed: int = 1000            # run r uses seed = base_seed + r

    # ---- variation operators -------------------------------------------
    crossover_prob: float = 0.9      # SBX probability (per pair)
    eta_c: float = 20.0              # SBX distribution index
    mutation_prob: float = None      # None -> 1/dim (standard default)
    eta_m: float = 20.0              # polynomial mutation distribution index

    # ---- metrics --------------------------------------------------------
    hv_mc_samples_final: int = 60000   # Monte-Carlo samples, final HV (M >= 3)
    hv_mc_samples_history: int = 4000  # cheaper HV for the per-iteration trace
    ref_front_size: int = 1000         # points sampled from the true Pareto front
    hv_margin: float = 0.10            # reference point offset beyond the nadir

    # ---- bookkeeping ----------------------------------------------------
    history_every: int = 1           # record convergence trace every g generations
    history_metric_runs: int = 10    # how many runs feed the averaged convergence
                                     # trace (HV per generation is the expensive
                                     # part; 10 runs is ample for a smooth curve)
    results_dir: str = "results"
    figures_dir: str = "figures"
    verbose: bool = True

    # ---- problem selection ---------------------------------------------
    # Empty by default -> main.py runs every one of the 27 benchmarks in
    # dataset.py: all 12 EvoPINN problems, ZDT1/ZDT2/ZDT3/ZDT4/ZDT6,
    # DTLZ1-DTLZ7, and the three Mixed min/max problems. Pass --problems on
    # the command line (or set this list) to restrict to a subset.
    problems: list = field(default_factory=list)

    def resolved_mutation_prob(self, dim):
        return (1.0 / dim) if self.mutation_prob is None else self.mutation_prob

    def ensure_dirs(self, root="."):
        root = Path(root)
        for d in (self.results_dir, self.figures_dir):
            (root / d).mkdir(parents=True, exist_ok=True)
        return root / self.results_dir, root / self.figures_dir

    def as_dict(self):
        return asdict(self)


# A small profile handy for smoke-testing the pipeline before the real run.
QUICK = NSGA2Config(n_population=40, archive_size=40, max_iterations=10,
                    n_runs=3, hv_mc_samples_final=5000,
                    hv_mc_samples_history=1000, ref_front_size=200)

DEFAULT = NSGA2Config()
