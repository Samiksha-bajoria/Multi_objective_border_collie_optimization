"""
density_estimation.py — NSGA-II's crowding-distance density estimator.

For every front (already partitioned by non-dominated rank), the crowding
distance of a solution is the sum, over every objective, of the normalised
gap between its two neighbours when the front is sorted along that
objective:

    d(i) = sum_j  (f_j(i+1) - f_j(i-1)) / (f_j_max - f_j_min)

Boundary solutions of a front (the best and worst on any objective) get an
infinite crowding distance, so they are never discarded by the
environmental-selection truncation step. This is NSGA-II's diversity
mechanism, used in place of SPEA2's k-th nearest-neighbour density rule —
same role (protect spread when trimming a front), different computation.

Objectives are only min-max *scaled per front* here for computing the
crowding distance; direction and raw objective values are never rewritten.
"""

import numpy as np


def crowding_distance(F):
    """Crowding distance for every member of ONE front, shape (n, m)."""
    F = np.asarray(F, dtype=float)
    n = F.shape[0]
    if n == 0:
        return np.zeros(0)
    if n <= 2:
        return np.full(n, np.inf)

    m = F.shape[1]
    dist = np.zeros(n)
    for j in range(m):
        order = np.argsort(F[:, j], kind='stable')
        f = F[order, j]
        span = f[-1] - f[0]
        dist[order[0]] = np.inf
        dist[order[-1]] = np.inf
        if span <= 0:
            continue
        dist[order[1:-1]] += (f[2:] - f[:-2]) / span
    return dist
