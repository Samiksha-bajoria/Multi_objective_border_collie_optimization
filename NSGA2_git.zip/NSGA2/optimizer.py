"""
optimizer.py — NSGA-II (Non-dominated Sorting Genetic Algorithm II).

Loop, exactly as in Deb, Pratap, Agarwal & Meyarivan (2002):

    P_0 <- random population, evaluate
    repeat
        mating pool <- crowded binary tournament on P_t (rank, crowding)
        Q_t <- SBX crossover + polynomial mutation of the mating pool
        R_t <- P_t U Q_t
        rank R_t into fronts F1, F2, ... by fast non-dominated sorting
        P_{t+1} <- fill front by front until the next front would overflow,
                   then take the highest-crowding-distance remainder of
                   that front (elitist replacement, exactly N_pop
                   individuals survive every generation)
    until t = max_iterations

Mixed minimise/maximise objective sets are supported natively: every
dominance test consults `problem['objective_types']`, and objective values
are stored exactly as the test function produced them.
"""

import time

import numpy as np

from archive import Archive
from crossover import crossover_population
from dataset import bounds_arrays
from mutation import polynomial_mutation
from selection import mating_pool


class NSGA2:
    def __init__(self, problem, config, seed=0):
        self.problem = problem
        self.config = config
        self.rng = np.random.default_rng(seed)
        self.seed = seed
        self.lower, self.upper = bounds_arrays(problem)
        self.dim = problem['dim']
        self.n_obj = problem['n_obj']
        self.types = problem['objective_types']
        self.p_mut = config.resolved_mutation_prob(self.dim)
        self.n_eval = 0

    # ------------------------------------------------------------------
    def _init_population(self):
        u = self.rng.random((self.config.n_population, self.dim))
        return self.lower + u * (self.upper - self.lower)

    def _evaluate(self, X):
        f = self.problem['evaluate']
        F = np.empty((len(X), self.n_obj))
        for i, x in enumerate(X):
            F[i] = f(x)
        self.n_eval += len(X)
        return F

    def _best_per_objective(self, F):
        """Direction-aware best value of every objective (no sign flipping)."""
        out = np.empty(self.n_obj)
        for j, t in enumerate(self.types):
            out[j] = F[:, j].min() if t == 'min' else F[:, j].max()
        return out

    # ------------------------------------------------------------------
    def run(self):
        cfg = self.config
        t0 = time.perf_counter()

        # NSGA-II keeps an elite population the same size as P_t every
        # generation; `archive_size` is that population size (see config.py).
        archive = Archive(cfg.archive_size, self.types)

        X = self._init_population()
        F = self._evaluate(X)

        hist = {'iteration': [], 'archive_size': [], 'front_size': [],
                'best': [], 'mean': [], 'snapshots': []}

        for it in range(1, cfg.max_iterations + 1):
            archive.update(X, F)

            if (it % cfg.history_every == 0) or it == cfg.max_iterations:
                Ff, _ = archive.front()
                hist['iteration'].append(it)
                hist['archive_size'].append(len(archive))
                hist['front_size'].append(len(Ff))
                hist['best'].append(self._best_per_objective(archive.F))
                hist['mean'].append(archive.F.mean(axis=0))
                hist['snapshots'].append(Ff.copy())

            if it == cfg.max_iterations:
                break

            parents = mating_pool(archive.X, archive.rank, archive.fitness,
                                  cfg.n_population, self.rng)
            children = crossover_population(parents, self.lower, self.upper,
                                            cfg.crossover_prob, cfg.eta_c,
                                            self.rng)
            children = polynomial_mutation(children, self.lower, self.upper,
                                           self.p_mut, cfg.eta_m, self.rng)
            X = children
            F = self._evaluate(X)

        runtime = time.perf_counter() - t0
        F_front, X_front = archive.front()

        return {
            'seed': self.seed,
            'archive_decisions': archive.X,
            'archive_fitness': archive.F,
            'archive_nsga2_fitness': archive.fitness,
            'front': F_front,
            'front_decisions': X_front,
            'runtime': runtime,
            'n_eval': self.n_eval,
            'history': hist,
        }


def run_single(problem, config, seed):
    """Convenience wrapper used by run_experiment.py."""
    return NSGA2(problem, config, seed=seed).run()
