"""
environmental_selection.py — how NSGA-II builds P_{t+1} from P_t U Q_t.

1. Rank the union into fronts F1, F2, ... (fitness.nsga2_fitness).
2. Copy whole fronts into P_{t+1}, front by front, for as long as they fit.
3. The first front that would overflow the population size is sorted by
   descending crowding distance and truncated to the remaining slots — this
   is what preserves spread/diversity at the cut, exactly as in the original
   NSGA-II paper (elitist replacement, no separate fitness-fill step needed
   because every front is already internally non-dominated).
"""

import numpy as np


def environmental_selection(X_union, F_union, fit_info, population_size):
    """
    X_union      : (N, dim)  decision vectors of P_t U Q_t
    F_union      : (N, M)    raw objective values
    fit_info     : output of fitness.nsga2_fitness on the same union
    Returns (X_next, F_next, selected_indices)
    """
    fronts = fit_info['fronts']
    crowding = fit_info['crowding']
    n = len(F_union)
    if n == 0:
        return X_union, F_union, np.array([], dtype=int)

    selected = []
    for front in fronts:
        if len(selected) + len(front) <= population_size:
            selected.extend(front.tolist())
        else:
            need = population_size - len(selected)
            if need > 0:
                order = front[np.argsort(-crowding[front], kind='stable')]
                selected.extend(order[:need].tolist())
            break

    sel = np.asarray(selected, dtype=int)
    return X_union[sel], F_union[sel], sel
