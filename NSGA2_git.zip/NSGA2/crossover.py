"""
crossover.py — Simulated Binary Crossover (SBX), bound-respecting.

Real-coded SBX is the standard recombination operator paired with NSGA-II
(and SPEA2) for continuous benchmarks (ZDT / DTLZ) and works unchanged for
the high-dimensional EvoPINN weight vectors.
"""

import numpy as np


def sbx(parent1, parent2, lower, upper, prob=0.9, eta=20.0, rng=None):
    """Return two children from two parents (per-variable SBX, p_var = 0.5)."""
    rng = np.random.default_rng() if rng is None else rng
    c1 = parent1.astype(float).copy()
    c2 = parent2.astype(float).copy()

    if rng.random() > prob:
        return c1, c2

    n = len(parent1)
    do_var = rng.random(n) <= 0.5
    close = np.abs(c1 - c2) <= 1e-14
    do_var &= ~close

    idx = np.flatnonzero(do_var)
    if idx.size == 0:
        return c1, c2

    x1 = np.minimum(c1[idx], c2[idx])
    x2 = np.maximum(c1[idx], c2[idx])
    lo, hi = lower[idx], upper[idx]
    dx = np.maximum(x2 - x1, 1e-14)
    u = rng.random(idx.size)

    def _child(beta_arg):
        alpha = 2.0 - beta_arg ** (-(eta + 1.0))
        betaq = np.where(u <= 1.0 / alpha,
                         (u * alpha) ** (1.0 / (eta + 1.0)),
                         (1.0 / (2.0 - u * alpha)) ** (1.0 / (eta + 1.0)))
        return betaq

    beta1 = 1.0 + 2.0 * (x1 - lo) / dx
    beta2 = 1.0 + 2.0 * (hi - x2) / dx
    bq1 = _child(beta1)
    bq2 = _child(beta2)

    y1 = 0.5 * ((x1 + x2) - bq1 * dx)
    y2 = 0.5 * ((x1 + x2) + bq2 * dx)
    y1 = np.clip(y1, lo, hi)
    y2 = np.clip(y2, lo, hi)

    swap = rng.random(idx.size) <= 0.5
    c1[idx] = np.where(swap, y2, y1)
    c2[idx] = np.where(swap, y1, y2)
    return c1, c2


def crossover_population(parents, lower, upper, prob=0.9, eta=20.0, rng=None):
    """Apply SBX pairwise across a shuffled mating pool."""
    rng = np.random.default_rng() if rng is None else rng
    pool = parents.copy()
    rng.shuffle(pool, axis=0)
    children = np.empty_like(pool)
    n = len(pool)
    for i in range(0, n - 1, 2):
        a, b = sbx(pool[i], pool[i + 1], lower, upper, prob, eta, rng)
        children[i], children[i + 1] = a, b
    if n % 2 == 1:
        children[-1] = pool[-1]
    return children
