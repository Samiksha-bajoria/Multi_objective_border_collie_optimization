"""
selection.py — mating selection.

NSGA-II fills the mating pool by binary tournament *with replacement*,
using the crowded-comparison operator: the winner is whoever has the
better (lower) rank; ties on rank are broken in favour of whoever has the
larger crowding distance (i.e. sits in a less crowded region of its own
front). No separate diversity tie-break is needed beyond that.
"""

import numpy as np


def binary_tournament(rank, crowding, n_select, rng):
    """Indices of the winners of `n_select` crowded binary tournaments."""
    n = len(rank)
    if n == 0:
        raise ValueError("empty population: cannot run mating selection")
    if n == 1:
        return np.zeros(n_select, dtype=int)

    a = rng.integers(0, n, size=n_select)
    b = rng.integers(0, n, size=n_select)
    same = a == b
    if np.any(same):
        b[same] = (b[same] + 1 + rng.integers(0, n - 1, size=same.sum())) % n

    a_wins = ((rank[a] < rank[b]) |
              ((rank[a] == rank[b]) & (crowding[a] > crowding[b])))
    winners = np.where(a_wins, a, b)
    return winners


def mating_pool(X_pop, rank, crowding, pool_size, rng):
    """Decision vectors of the selected parents."""
    idx = binary_tournament(np.asarray(rank), np.asarray(crowding, dtype=float),
                            pool_size, rng)
    return X_pop[idx].copy()
